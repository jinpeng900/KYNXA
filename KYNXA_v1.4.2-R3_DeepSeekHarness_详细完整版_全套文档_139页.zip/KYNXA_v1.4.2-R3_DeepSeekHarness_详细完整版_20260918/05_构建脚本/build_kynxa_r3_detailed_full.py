from pathlib import Path
import shutil, re, json, hashlib, csv, os, textwrap, subprocess, sys
from datetime import datetime

SRC = Path('/mnt/data/KYNXA_v1.4.2-R3_20260918_最新完整文档包_34页')
OUT = Path('/mnt/data/KYNXA_v1.4.2-R3_DeepSeekHarness_详细完整版_20260918')
if OUT.exists(): shutil.rmtree(OUT)
(OUT/'00_说明与总览').mkdir(parents=True)
(OUT/'01_统一详细主文档').mkdir()
(OUT/'02_专项详细设计_MD').mkdir()
(OUT/'03_架构图').mkdir()
(OUT/'04_统计与校验').mkdir()
(OUT/'05_构建脚本').mkdir()

src_md = SRC/'02_专项设计_MD'

# module specifications used to expand the compact R3 set into a codable full edition.
mods = {
'00_Global_Engineering_Contract_全局工程契约_安全不变量与跨模块协议_R3.md': dict(
    title='00 · Global Engineering Contract · 全局工程契约、安全不变量与跨模块协议',
    owns=['跨模块术语、稳定 ID、revision/schema_version 规则','Trust Zone 与 less-trusted / trusted 边界','CapabilityRequest / ApprovalIntent / AuthorizationGrant / SideEffectRecord 的规范语义','IPC Envelope、correlation/causation、错误分类与幂等要求','Model Policy 与 Authority Policy 的正交关系'],
    notowns=['具体 GUI 布局','具体模型算法','具体 Skill SOP','某个 Provider 的私有实现'],
    objects=['ContractId','ScopeRef','RevisionRef','CapabilityRequest','ApprovalIntent','AuthorizationGrant','SideEffectRecord','ModelExecutionPlan','EventEnvelope','CheckpointRef'],
    services=['Contract Registry','Schema Compatibility Gate','Scope Resolver','Revision Validator','Event Envelope Validator'],
    flows=['任何模块构造跨进程请求前先绑定 scope/revision/schema_version','受保护动作 canonicalize 后形成 request_hash','Authority 只消费结构化请求，不消费模型自然语言作为授权事实','副作用进入 PREPARED→SENT→CONFIRMED/UNKNOWN/FAILED ledger','协议升级通过显式 Contract Migration，而不是局部绕过'],
    invariants=['SEC-001：LLM/Planner/Router/Skill/DSH Runtime 不拥有 ambient host privilege','SEC-002：Approval != Execution，审批结果不能替代 Grant 校验','SEC-003：Credential 只允许 use-by-reference，不进入模型上下文与普通日志','SEC-004：Graph/Policy/Scope/参数 revision 变化使旧批准失效','SEC-005：non-idempotent side effect 在 UNKNOWN 状态禁止盲重试','SEC-006：Web/Knowledge/Community Skill 均视为不可信数据','SEC-007：Full Access 只能放宽交互频率，不关闭 Authority/Audit/Kill Switch'],
    failures=['协议版本不兼容→拒绝并返回 CONTRACT_VERSION_UNSUPPORTED','scope 缺失/漂移→SCOPE_MISMATCH','revision 过期→STALE_REVISION','重复副作用 claim→ALREADY_CLAIMED/RECONCILE','Authority 不可用→Fail Closed'],
    metrics=['contract_validation_failures_total','stale_revision_reject_total','approval_digest_mismatch_total','side_effect_unknown_total','scope_violation_total'],
    tests=['修改审批后的 path/amount，旧 Grant 必须失效','模拟 Python/Node Runtime RCE，不能越过 Authority 读取未授权用户目录','同一 max_uses=1 Grant 在手机和 PC 并发 claim，只能成功一次','支付网络超时进入 UNKNOWN 后只能 reconciliation','Cloud=DENY 时任何 Skill/Router 都不能静默外传 Work 内容'],
    milestones=['先冻结 JSON Schema/IDL 与 Contract ID','为 Host/Authority/Agent Runtime 建 shared conformance tests','把旧散落错误码收敛到统一 taxonomy','把 Contract tests 设为 release gate']
),
'01_总体系统架构与产品蓝图_R3.md': dict(
    title='01 · 总体系统架构与产品蓝图',
    owns=['Windows-first Local Agent Host 产品拓扑','WinUI Desktop、C# Host、Node/TypeScript DeepSeek Harness Runtime、Rust Authority、Model Runtime、Resident/Network sidecar 的进程边界','Chat / Work / Knowledge / Models / Skills / Remote / Inbox 的产品信息架构','启动、停止、升级、崩溃恢复与最小驻留策略'],
    notowns=['各模块内部算法细节','具体 Provider API 字段','每个 Skill 的业务 SOP'],
    objects=['AppSession','HostInstance','RuntimeInstance','AuthorityInstance','WorkRef','ConversationRef','TaskRef','ResidentState','NetworkProfileRef'],
    services=['kynxa-desktop.exe','kynxa-host.exe','kynxa-agent-runtime (Node/TS)','kynxa-authority.exe','kynxa-model-runtime','kynxa-resident','kynxa-net sidecar','optional Python workers'],
    flows=['Desktop 启动 Host，Host 完成 DB migration 与 Authority handshake','普通 Chat 可创建无 Work 的 Conversation；Work 是长期 scope','需要 Agent 循环时 Host 创建/恢复 DSH session 并绑定 TaskNode','危险 Tool Intent 经 Authority 生成 Grant 后由 Restricted Executor 执行','长任务结果、Artifact、CognitiveState 与 Session lineage 都可在 Host 重启后恢复'],
    invariants=['Desktop 不直写 authority.db','Agent Runtime 不拥有数据库安全真相','Python 仅作为 specialized worker，不再作为中央 Agent Orchestrator','Work 逻辑树与磁盘目录解耦','本地模型不可用时不能自动把内容上传云端，除非策略明确允许'],
    failures=['Agent Runtime crash→Host 重启并 resume session','Model Runtime OOM→按用户策略降级量化/模型/CPU 或失败','Authority crash→受保护动作全部停止','Desktop crash→Host 可继续后台任务或进入可恢复状态','DB migration failure→只读/恢复模式，不继续写入'],
    metrics=['startup_time_ms','host_ready_time_ms','runtime_restart_total','task_resume_success_rate','authority_handshake_fail_total','resident_idle_memory_mb'],
    tests=['冷启动到可聊天','运行中杀死 Agent Runtime 后恢复 Task','运行中杀死 Desktop，后台 Task 状态保持','Authority 断开时危险动作 fail closed','多个 Child Work 移动时循环检测正确'],
    milestones=['Vertical Slice：Work→repo→DSH agent→sandbox build→patch→test→checkpoint→kill/resume','再接 Knowledge/Model Management/Remote','最后启用 routine/commerce 等高风险域']
),
'02_产品功能需求与_GUI_交互详细设计_R3.md': dict(
    title='02 · 产品功能需求与 GUI 交互详细设计',
    owns=['1440×900 基准 WinUI 3 桌面信息架构','侧边栏、顶部栏、主内容区、预览区与可拖动分隔条','Chat/Work/Models/Skills/Knowledge/Inbox/Settings 页面','流式消息、附件、引用、预览、审批卡、任务状态与错误恢复交互','模型管理独立可拖动小窗口'],
    notowns=['模型推理实现','Authority 内部策略求值','网络隧道实现'],
    objects=['NavigationItem','ConversationCard','WorkCard','MessageBlock','AttachmentRef','CitationRef','PreviewPaneState','ApprovalCard','ModelManagerWindowState','SplitterLayout'],
    services=['ShellWindow','NavigationViewModel','ChatViewModel','WorkViewModel','PreviewService','ApprovalCenterViewModel','ModelManagerWindow','LayoutPersistenceService'],
    flows=['启动默认进入 Chat；侧边栏支持折叠和宽度拖动','消息流式到达时做 chunk coalescing，避免逐 token UI 更新','点击引用/附件在预览区打开，预览区宽度可拖动','进入 Work 后左侧仍保留该 Work 的 Conversation 列表','模型管理从 Settings/顶部入口打开独立子窗口，支持关闭/最小化/最大化/拖动'],
    invariants=['UI 不显示安全能力即等于授权；审批必须来自 Authority Intent','普通用户不直接编辑数据库/路径/secret','所有可拖动区域保存合法 min/max 尺寸，窗口缩小时先保证主对话可用','对话图标、导航图标保持统一小尺寸与 WinUI 视觉层级','不以 WebView2 作为主 GUI 实现'],
    failures=['Preview renderer 不支持→回退到系统打开/文本摘要','流式断线→保留已显示内容并提供 Retry/Resume','模型不可用→显示 capability/fallback 原因','审批过期→卡片明确标记 Expired 而不是静默失败','布局配置损坏→回到 1440×900 默认布局'],
    metrics=['first_interactive_ms','stream_ui_updates_per_sec','preview_open_ms','approval_decision_latency_ms','layout_restore_fail_total'],
    tests=['1440×900、1920×1080、125%/150% DPI 无裁切','侧边栏/预览/顶部区域拖动后重启恢复','Work 内多 Conversation 左栏可滚动并保留最近对话渐进感','模型管理窗口独立拖动/最大化且不阻塞主窗口','大量 token 流式时 UI 线程无明显卡顿'],
    milestones=['先冻结 Shell/Chat/Work/Preview 基础组件','再接 Approval/Model Manager','最后接 Android Remote 状态与开发者诊断视图']
),
'03_Work_Conversation_与模型无关_CognitiveState_R3.md': dict(
    title='03 · Work、Conversation 与模型无关 CognitiveState',
    owns=['Work/Child Work 长期 Scope','Conversation、Task、TaskNode 与 CognitiveState 分层','Checkpoint/Snapshot/Handoff/Context Compiler','TaskGraph revision 与跨模型恢复','DSH SessionBinding 与 session lineage'],
    notowns=['DSH 内部 turn/step 历史实现','长期 Knowledge 本体','Authority Grant 真相'],
    objects=['Work','Conversation','Task','TaskNode','CognitiveState','Checkpoint','SessionBinding','ContextBundle','ArtifactRef','DecisionRef'],
    services=['WorkService','TaskService','CognitiveStateReducer','CheckpointService','ContextCompiler','SessionBindingService'],
    flows=['Conversation 可属于 Work 或为普通 Chat','TaskGraph 外层负责 durable node、依赖、审批、预算、恢复','RUNNING_AGENT 节点创建/恢复 DSH SessionBinding','模型切换通过 ContextBundle/Handoff，而不是迁移 KV/CoT','Checkpoint 固化关键 Observation、Artifact、side-effect 引用与 graph_revision'],
    invariants=['CognitiveState 不保存私有 chain-of-thought 作为业务真相','Work 删除采用 tombstone/retention，不直接抹除审计','Child Work 具有独立 scope，不因父级查看而自动扩权','session_id 不是 task_id；一项 Task 可产生 session lineage','Context 编译必须显式带 scope/revision 和 provenance'],
    failures=['session 丢失→从最新 Checkpoint 创建新 generation','graph revision 冲突→节点停止并重新规划','并发修改 Work→optimistic revision conflict','Context 超预算→按重要性压缩，Authority/side-effect refs 不得摘要丢失','Artifact 缺失→标记 degraded evidence'],
    metrics=['checkpoint_write_ms','resume_success_rate','context_bundle_tokens','graph_revision_conflict_total','session_generation_count'],
    tests=['模型 A→模型 B 后目标/约束/证据/Verifier 状态不丢','Host kill 后从 checkpoint 恢复','移动 Child Work 做循环检测','同 TaskNode 两个并发 worker 不允许重复 side effect','长期会话 compaction 后仍能恢复关键决策'],
    milestones=['先实现 Work/Conversation/Task schema','再实现 reducer/checkpoint','最后接 DSH session mapping 与跨模型 handoff']
),
'04_知识_记忆_经验与决策记忆系统_R3.md': dict(
    title='04 · 知识、记忆、经验与决策记忆系统',
    owns=['Conversation/Work/Personal/Community 四层 Knowledge','Memory、Decision Memory、Experience 与 Skill 的职责分离','解析、Chunk、Hybrid Retrieval、Rerank、Provenance、时间版本','Work Capsule 与可忘记/GC','RAG Evidence 到 ContextBundle 的可追溯映射'],
    notowns=['Tool 权限','模型内部记忆','Session event log'],
    objects=['KnowledgeSource','DocumentVersion','Chunk','EmbeddingRecord','MemoryItem','DecisionRecord','ExperienceRecord','ProvenanceEdge','RetrievalTrace'],
    services=['IngestionService','ParserWorkers','Chunker','FTSIndex','VectorIndex','Reranker','MemoryGovernance','DecisionMemoryService','ExperienceBank'],
    flows=['Source 导入→hash/version→解析→chunk→FTS/vector 索引','查询先按 scope/ACL/时间过滤，再 dense+sparse 召回并 rerank','关键 Decision 以 supersedes 关系更新，不靠文本覆盖','Experience 由任务结果与 verifier 证据晋升，失败经验同样可记录','Evidence 以引用形式进入 ContextBundle，保留 source/version/chunk offsets'],
    invariants=['Vector DB 不是 Source of Truth','Knowledge 不等于 Memory，事实不能因“记忆”而覆盖更新文档','Community/Web 内容始终是不可信输入','删除/忘记必须能传播到索引与 derived cache','跨 Work 默认禁止检索私有知识'],
    failures=['parser crash→隔离重试并保留原文件','embedding provider 变更→异步重建索引','source 文件更新→生成新 version，不就地篡改 provenance','检索冲突→显式展示版本/来源而非强行合并','索引损坏→从 SQLite+files 重建'],
    metrics=['ingest_docs_per_min','retrieval_recall_at_k','rerank_latency_ms','stale_index_ratio','orphan_chunk_total','memory_gc_total'],
    tests=['Work A 查询不能命中 Work B 私有文档','更新文档后旧引用仍可解析到历史版本','删除源后索引最终一致清除','Decision supersedes 链可追溯','RAG answer citation 可跳转到原文页/段'],
    milestones=['先做文件/PDF/DOCX/代码 ingestion + FTS','再加 vector/rerank','最后加 Experience/Decision/Community pack']
),
'05_Skill_Tool_MCP_与社区能力生态_R3.md': dict(
    title='05 · Skill、Tool、MCP 与社区能力生态',
    owns=['Tool 原子执行语义与 Skill Procedure/SOP 分离','SKILL.md-first 包格式、manifest/lock/resources/scripts/tests','MCP 与第三方仓库适配','Skill registry、版本、信任、回归与来源锁定','DSH skill/tool/MCP runtime 复用和 KYNXA governance'],
    notowns=['权限授予','模型选择最终决定','原生 Tool 的 OS 特权执行'],
    objects=['ToolDefinition','SkillPackage','SkillManifest','SkillLock','SkillVersion','ToolBinding','McpServerProfile','SkillTestResult','PublisherTrust'],
    services=['SkillCatalog','SkillInstaller','SkillScanner','SkillCompiler/Adapter','MCPManager','ToolSchemaBridge','RegressionGate'],
    flows=['安装来源固定 commit/hash→静态扫描→sandbox test→Candidate','Verified Skill 运行时通过 DSH 按需加载','Skill 声明 capability requirement，但 Authority 独立授权','MCP Server 暴露工具先转 KYNXA Tool schema 再进入 Tool Bridge','版本升级保留 lock 与 regression result，失败可回滚'],
    invariants=['Install != Trusted != Authorized','存在 script 不代表可直接执行；必须走 Tool/Authority','Skill preference 不能覆盖用户显式 Model/Privacy Policy','第三方 MCP 的 tool description 视为不可信 metadata','Community 包不得写 policy/credential store'],
    failures=['依赖不可解析→安装失败但不污染已验证版本','MCP server 超时→断路器/熔断','Tool schema 变更→compatibility gate','Skill 回归失败→保持旧 verified 版本','供应链 hash 不一致→立即 quarantine'],
    metrics=['skill_install_success_rate','skill_regression_pass_rate','mcp_tool_latency_ms','tool_schema_mismatch_total','quarantined_package_total'],
    tests=['恶意 Skill 请求读取 Credential→Authority 拒绝','Skill 升级后旧 lock 可回滚','MCP 返回 prompt injection 文本只作为 data','DSH skill 按需加载不扩大 tool catalog','离线安装本地 package 可完成验证'],
    milestones=['先实现本地 SKILL.md + Tool registry','再接 MCP','再做 GitHub/GitLab/Gitee source + trust UI']
),
'06_DeepSeek_Harness_集成_持久任务编排与_Agent_执行内核_R3.md': dict(
    title='06 · DeepSeek Harness 集成、持久任务编排与 Agent 执行内核',
    owns=['DeepSeek Harness 作为 Agent Execution Engine 的集成边界','KYNXA Durable TaskGraph 与 DSH Session/Agent Loop 的双层运行模型','State/Context/Model/Tool/Event/Telemetry Adapter','subagent/workflow/skill/web/compaction 的启用策略','upstream 跟踪、bundle/profile 与最小 patch 策略'],
    notowns=['重新实现 ReAct/agent loop','让 DSH Workspace 替代 KYNXA Work','让 DSH approval/sandbox 取代 Rust Authority'],
    objects=['AgentRuntimeProfile','DshSessionRef','SessionBinding','ContextBundle','ModelRouteHandle','ToolIntent','ToolObservation','RuntimeEvent','SessionLineage'],
    services=['kynxa-agent-runtime','DshCompositionFactory','ContextAdapter','ModelAdapter','AuthorityToolBridge','EventAdapter','TelemetryAdapter','SessionLifecycleManager'],
    flows=['Host 创建 TaskNode→Runtime CreateSession/ResumeSession','agent-loop 请求模型→LLM seam 调 KYNXA Model Resolver','模型 tool call→DSH tools→KYNXA Tool Bridge→Authority/Executor','结果写回 DSH append-only session log，同时投影到 Host Event Stream','Node 结束后 Host 再执行 programmatic verifier 并更新 CognitiveState/Checkpoint'],
    invariants=['默认只通过 upstream extension/plugin/profile 扩展，不 fork core','DSH Session 是 agent 执行事实，不是 KYNXA Work/Task 业务真相','DSH storage/workspace 为 host-side runtime 辅助状态，不拥有 KYNXA 数据模型','任何 child/subagent 的危险 tool 同样经过 Authority','Runtime 不读取 authority.db、不持有长期 credential'],
    failures=['Runtime crash→重启并 resume persisted session','session schema 不兼容→migration gate/新 generation','tool UNKNOWN→reconcile before retry','upstream 升级导致 adapter contract 变化→compat matrix 阻断发布','compaction 丢关键引用风险→Host 用 pinned context refs 校验'],
    metrics=['agent_turn_latency_ms','tool_intent_total','parallel_tool_call_peak','session_resume_ms','runtime_crash_total','adapter_contract_error_total','tokens_per_task'],
    tests=['kill runtime 中途恢复 session','child subagent 不能绕过 Authority','用户 Strict Coder 无 vision 时返回 capability unavailable','Work 与 DSH Workspace 名称/删除语义互不污染','upstream core 升级跑 session/tool/subagent/workflow 回归'],
    milestones=['建立 dsh-base/minimal 的 kynxa profile','实现六类 Adapter','迁移旧自研 agent loop 调用点','启用 subagent/workflow','建立 upstream 自动兼容测试']
),
'07_模型管理_本地模型运行时与异构消费级硬件自适应_R3.md': dict(
    title='07 · 模型管理、本地模型运行时与异构消费级硬件自适应',
    owns=['模型管理 UI：本地/官方/自定义','Model Registry、Provider、Model ID、能力检测与成本元数据','本地 GGUF/llama.cpp-derived runtime 与硬件探测','显存/内存预算、量化、KV、offload、并发与 OOM fallback','Global→Work→Conversation→Skill→TaskNode Model Policy'],
    notowns=['Authority 安全授权','DSH agent loop','用户长期 Knowledge'],
    objects=['ModelProvider','ModelDescriptor','ModelCapability','ModelRoutingProfile','ModelExecutionPlan','HardwareFingerprint','RuntimeProfile','ModelUsageTrace','CredentialRef'],
    services=['ModelManager','ProviderAdapter','CapabilityProbe','HardwareProfiler','LocalModelRuntime','ModelResolver','ResourceScheduler'],
    flows=['添加 provider→连接测试→获取/手动 Model ID→能力探测','用户选择 Smart/Prefer Selected/Strict','TaskNode 提交 capability requirements→Resolver 生成 execution plan','本地 runtime 根据 VRAM/RAM 决定量化/offload/context/KV','OOM/失败时按 policy 选择小模型/CPU/失败，不擅自 cloud fallback'],
    invariants=['模型路由与 Authority 权限路由完全解耦','API Key 使用 Credential Broker 引用','Cloud fallback 默认 DENY','模型切换不改变 CognitiveState 真相','本地模型生命周期由 KYNXA 管理，不要求用户安装外部 Ollama'],
    failures=['provider 401→credential/config error','429/5xx→受限重试与退避','本地 OOM→资源回收/小模型/低 context/CPU fallback','capability probe 不确定→标 unknown，不猜支持','模型下载中断→断点/校验后继续'],
    metrics=['ttft_ms','tokens_per_sec','vram_peak_mb','model_load_ms','oom_total','provider_error_rate','routing_fallback_total'],
    tests=['4060/8GB 等低显存设备选择合适 profile','5090 高显存可扩大 context/batch 但不改变语义','Strict model 缺 Vision 不调用别的云模型','自定义 OpenAI Compatible provider 获取模型列表','本地与云切换后 task 恢复一致'],
    milestones=['先做 Registry+OpenAI/Anthropic compatible','再做 Local Runtime','再做自动硬件 profile 与多模型协作']
),
'08_能力模块_浏览器_计算机_文件_代码与_Artifact_R3.md': dict(
    title='08 · 能力模块：浏览器、计算机、文件、代码与 Artifact',
    owns=['File/Code/Sandbox/Browser/Computer/Web/Document/Vision/Artifact Tool family','输入/输出 Schema、capability class、risk level、timeout 与 verifier','Preview/Artifact 版本与 provenance','Computer Use 与直接 API/DOM 的优先级','Restricted Executor 与 sandbox 约束'],
    notowns=['最终授权','Skill 高层流程','模型选择'],
    objects=['ToolRequest','ToolResult','FileRef','Artifact','BrowserSession','ComputerSession','SandboxRun','PatchSet','DocumentView','VisionObservation'],
    services=['FileExecutor','CodeExecutor','SandboxManager','BrowserWorker','ComputerWorker','ArtifactService','DocumentRenderer','VisionWorker'],
    flows=['只读工具优先并行；写操作串行且经过 canonical path','代码修改先生成 patch/diff，再测试与 verifier','Browser 优先结构化 DOM/API，必要时再视觉/Computer Use','Artifact 每次重要修改生成版本与来源链','文件上传/下载/外部发送均重新进入 capability check'],
    invariants=['路径必须 canonicalize 并防 TOCTOU/path escape','工具返回内容视为 untrusted observation','直接屏幕/键鼠控制默认更高风险','Artifact 不等于原始文件；必须有 source/provenance','Replay 模式不得真实重放支付/发送等副作用'],
    failures=['sandbox 超时→终止进程树并保留日志','browser page crash→重建 session','文件被外部修改→etag/hash 冲突','patch apply conflict→请求重新读取上下文','Computer worker 失去焦点→暂停而非盲点击'],
    metrics=['tool_success_rate','sandbox_timeout_total','browser_navigation_ms','patch_apply_conflict_total','artifact_versions_total'],
    tests=['路径穿越/符号链接逃逸被阻止','build→error→patch→test vertical slice','Browser 页面 prompt injection 不能触发越权 tool','大文件预览不一次读入 UI','Computer Use 操作前后截图/状态 verifier 可关联'],
    milestones=['先 File/Code/Sandbox/Artifact','再 Browser/Web','最后 Computer/Vision 高风险交互']
),
'09_安全架构_权限系统与_Full_Access_R3.md': dict(
    title='09 · 安全架构、权限系统与 Full Access',
    owns=['独立 Rust Trusted Authority Core','Capability Broker、Policy Engine、Approval Validator、Grant Manager、Credential Broker、Audit、Financial hard boundary','L0-L4 风险、Scope/Duration/Budget、Full Access policy mode','OS-level isolation、Named Pipe ACL/identity/nonce/replay protection','side-effect ledger 与 kill switch'],
    notowns=['Planner 意图','DSH session','业务 GUI 状态'],
    objects=['Policy','CapabilityRequest','CanonicalAction','ApprovalIntent','AuthorizationGrant','CredentialRef','AuditEvent','SideEffectRecord','DeviceIdentity'],
    services=['kynxa-authority.exe','PolicyEngine','CapabilityBroker','ApprovalService','GrantManager','CredentialBroker','AuditLedger','SideEffectCoordinator'],
    flows=['Tool Intent→canonicalization→policy evaluate','低风险内建 Grant 或生成 ApprovalIntent','用户批准绑定 request_hash/policy_revision/graph_revision','Executor claim Grant→执行→commit SideEffectRecord','UNKNOWN 副作用进入 query/reconcile，禁止自动重复执行'],
    invariants=['Authority 默认无普通 Internet egress','Secret 不进入模型/普通 DB/日志','Full Access 不关闭 L4/credential/audit/kill switch','所有远程审批与本机审批共享同一一次性决议语义','Host/Node/Python 进程即便 RCE 也不应直接获得高权限资源'],
    failures=['Authority unavailable→fail closed','Grant expired/claimed→拒绝','canonicalization 无法确定→拒绝','credential backend locked→需要用户解锁','audit 写失败→高风险动作不继续'],
    metrics=['approval_required_total','grant_denied_total','grant_claim_conflict_total','credential_access_total','audit_write_fail_total','security_violation_total'],
    tests=['恶意网页诱导上传 SSH key→拒绝','批准后修改金额→旧批准失效','Full Access 下金融动作仍需硬边界','模拟 Host RCE 不能直接读 Credential','remote device revoke 后立即失去审批权'],
    milestones=['先实现 Capability/Grant/Audit 最小闭环','再加 Credential/Device/Financial','最后做系统化红队与 AgentDojo/Promptfoo 回归']
),
'10_Resident_Android_远程控制_设备配对与统一审批中心_R3.md': dict(
    title='10 · Resident、Android 远程控制、设备配对与统一审批中心',
    owns=['Windows Resident 最小常驻、Host start/wake/health','Android Control Plane、QR 一次性配对与设备密钥','RemoteSession role/permission','远程 Task 指令、状态、审批与可选 Screen stream','设备撤销与多设备并发'],
    notowns=['模型推理常驻','任意远程桌面软件替代','Authority policy'],
    objects=['Device','PairingIntent','RemoteSession','RemoteCommand','RemoteApproval','ScreenStreamSession','ResidentHealth'],
    services=['kynxa-resident','Android Client','DeviceRegistry','PairingService','RemoteGateway','ScreenStreamWorker'],
    flows=['PC Resident 等待已配对设备→认证→可启动 Host','QR pairing 只在短时窗口有效并交换设备公钥','Phone Controller 与 Tablet Viewer 可建立独立 session','远程 approval 最终提交到同一 Authority ApprovalIntent','Screen worker 按需启动，session 结束退出'],
    invariants=['网络可达不等于 KYNXA 授权','Resident 不加载模型、不保存原始 Credential','Viewer 默认只读，Controller 也不自动获得 direct input','设备撤销立即使后续 token/session 无效','远程命令必须带 device/session identity'],
    failures=['Host 未运行→Resident start host','网络切换→session 重连但不重复执行 side effect','设备时钟漂移→nonce/sequence 而非仅靠时间','Screen encoder crash→控制通道仍可用','pairing code 重放→拒绝'],
    metrics=['resident_idle_mb','remote_connect_ms','pairing_success_rate','remote_command_latency_ms','screen_fps','revoked_session_reject_total'],
    tests=['手机 5G + 平板热点同时连接 PC','撤销设备后旧 session 失效','Host crash 后手机可请求重启并恢复 task','远程审批与 PC 并发只消费一次 Grant','Viewer 不能发送控制命令'],
    milestones=['先 pairing+task status+approval','再 host lifecycle','最后 screen view/direct input 可选能力']
),
'11_Agent_Wallet_购物_Skill_与_Agent_Commerce_R3.md': dict(
    title='11 · Agent Wallet、购物 Skill 与 Agent Commerce',
    owns=['商品比较/购物卡/订单意图','PaymentIntent 与 Financial Policy','不托管资金原则','支付认证与多设备批准','Outbox/Reconciliation、Skip Today、预算与商家策略'],
    notowns=['银行清算','保存银行卡明文','让模型直接调用支付凭证'],
    objects=['ProductCandidate','ShoppingPlan','OrderIntent','PaymentIntent','MerchantProfile','FinancialPolicy','PaymentSideEffect'],
    services=['ShoppingSkill','CommerceAdapter','PaymentCoordinator','MerchantVerifier','FinancialPolicyEngine(Authority-owned parts)'],
    flows=['检索商品→生成候选与证据→用户/策略选择','创建 OrderIntent→最终金额/商家/商品 canonicalize','PaymentIntent 进入 Authority L4 hard boundary','外部支付结果不确定→reconciliation 查询','拒绝可进入 Skip Today/替代商品/结束'],
    invariants=['模型永远拿不到可复用支付 secret','价格/数量/收货地址变化使批准失效','不得把“已发送请求”误报为“已成功支付”','自动购买只在明确预算/商家/品类/上限 scope 内','默认保留可审计订单与理由'],
    failures=['价格变化→重新确认','库存消失→重新计划','支付网关超时→UNKNOWN','商家身份无法确认→阻断','多设备重复确认→只一次成功'],
    metrics=['commerce_plan_to_order_rate','price_change_reapproval_total','payment_unknown_total','reconciliation_latency_ms'],
    tests=['批准后金额被篡改→拒绝','支付超时不二次扣款','预算超限→Authority 阻断','模拟商家/沙盒环境端到端测试','购物推荐明确区分事实、偏好和广告/推广来源'],
    milestones=['先只做比较/购物清单','再沙盒订单','最后受控真实支付集成']
),
'12_Routine_Intent_Subscription_与个人自动化_R3.md': dict(
    title='12 · Routine、Intent Subscription 与个人自动化',
    owns=['Cron/事件/条件/意图订阅统一触发模型','RoutineRun 状态机、去重、Snooze/Pause/Skip','上下文感知自动化与预算','休眠/时区/DST/错过运行','自动化的权限与通知策略'],
    notowns=['任意后台无限循环 Agent','自动授予新权限','绕过用户 quiet hours'],
    objects=['Routine','Trigger','IntentSubscription','RoutineRun','RunBudget','NotificationPolicy','DedupKey'],
    services=['RoutineScheduler','TriggerEngine','IntentMatcher','RunCoordinator','NotificationService'],
    flows=['Trigger 命中→创建唯一 Run→加载 scope/context→执行 deterministic/agent node','高风险动作仍进入 Approval','失败按策略 retry/backoff 或等待用户','休眠后按 catch-up policy 决定补跑/跳过','重复事件通过 dedup key 合并'],
    invariants=['自动化不能扩大原授权 scope','条件 watch 最高频率/资源预算受限','长期运行必须有可暂停/停止/审计入口','Quiet hours 默认抑制非紧急打扰','Intent Subscription 解释 why triggered'],
    failures=['系统休眠→恢复时 reconciliation','时区变化→按 schedule semantics 重算','同一事件多次到达→幂等去重','模型不可用→可降级 deterministic path 或延迟','通知通道失败→保留 Inbox item'],
    metrics=['routine_runs_total','dedup_suppressed_total','missed_run_total','run_latency_ms','user_snooze_rate'],
    tests=['DST 切换不重复关键动作','PC 睡眠后按策略补跑','重复 webhook 只创建一项 Run','Routine 无权限时进入 Needs You 而非静默失败','用户 Pause 后不再触发'],
    milestones=['先本地 schedule','再事件/条件','最后 Intent Subscription 与多设备控制']
),
'13_个人_Agent_体验_偏好学习_Shadow_Mode_与_Agent_Constitution_R3.md': dict(
    title='13 · 个人 Agent 体验、偏好学习、Shadow Mode 与 Agent Constitution',
    owns=['结构化偏好与 Agent Constitution','Teach KYNXA、Why Asking、Shadow Mode','Do-it-and-tell-me/Inbox/每日简报','偏好证据、置信度、可撤销与可忘记','探索度与个性化边界'],
    notowns=['敏感属性推断','隐藏式政治/商业操纵','把偏好当权限'],
    objects=['Preference','PreferenceEvidence','ConstitutionRule','ShadowSuggestion','UserFeedback','BriefingItem'],
    services=['PreferenceService','ConstitutionEvaluator','ShadowModeService','FeedbackRouter','BriefingComposer'],
    flows=['用户显式 Teach 或从重复行为生成低置信候选','候选先在 Shadow Mode 观察，不直接自动执行','用户确认后提升 preference confidence','冲突偏好按 scope/time/source 解析','Why Asking 展示触发规则与当前假设'],
    invariants=['Preference != Permission','敏感个人属性默认不推断/不固化','用户可查看、编辑、忘记偏好来源','失败反馈优先修正行为，不强行解释用户','个人化不能覆盖 Authority/Privacy 硬边界'],
    failures=['偏好冲突→降级为询问或 scope-specific rule','低置信候选→保持 shadow','用户撤销→后续 context 不再注入','摘要过度个性化→可关闭/回到中性模式','数据删除后 derived cache 同步清理'],
    metrics=['shadow_accept_rate','preference_reversal_rate','why_asking_open_rate','briefing_dismiss_rate'],
    tests=['用户修改偏好立即影响后续 task','忘记偏好后不再出现','Shadow suggestion 不产生真实 side effect','Work 特定偏好不泄漏到其他 Work','偏好不能替代审批'],
    milestones=['先 explicit preference','再 shadow learning','最后 briefing/constitution 与长期治理']
),
'14_缓存_存储_快照_回放_可观测性与灾难恢复_R3.md': dict(
    title='14 · 缓存、存储、快照、回放、可观测性与灾难恢复',
    owns=['Cache/Reuse 与业务真相分离','Checkpoint/Snapshot/Event/Flight Recorder','Replay 与 side-effect mock/reconciliation','Crash recovery、backup、restore、migration','日志/trace/metrics 的隐私与采样'],
    notowns=['KYNXA 业务 schema 本身（见 17）','Authority policy 本身','模型算法'],
    objects=['CacheEntry','Checkpoint','Snapshot','EventRecord','TraceSpan','BackupManifest','RecoveryPlan'],
    services=['CacheService','CheckpointStore','SnapshotManager','FlightRecorder','BackupService','RecoveryCoordinator'],
    flows=['deterministic cache 按 input hash/model/tool/version/scope 键控','任务关键节点写 checkpoint','定期/升级前生成 snapshot/backup manifest','Crash 后先恢复 truth store，再重建 derived index/cache','Replay 默认替换外部副作用为 recorded result/mock'],
    invariants=['Checkpoint != Cache','Cache 可删可重建，不得承载唯一事实','Replay 不真实重复支付/发送/删除','Trace 默认不记录 secret/full sensitive prompt','备份与恢复必须包含 schema/version/manifest 校验'],
    failures=['cache corruption→丢弃重建','snapshot 不完整→拒绝标记成功','恢复时版本不兼容→migration/只读模式','日志磁盘占满→降级采样且保护业务库','Flight Recorder 关闭时核心审计仍由 Authority 保留'],
    metrics=['cache_hit_rate','checkpoint_latency_ms','snapshot_size_mb','recovery_time_objective_ms','replay_success_rate','trace_drop_total'],
    tests=['删掉所有 vector/cache 后系统可重建','task kill/restart 保持 side-effect once semantics','备份到新机器恢复 Work/Artifact 引用','Replay payment 只用 mock','磁盘满时不损坏 SQLite'],
    milestones=['先 checkpoint/flight recorder','再 backup/restore','最后 deterministic replay 与灾难演练']
),
'15_研究价值_开源_Benchmark_实验评估与开发路线_R3.md': dict(
    title='15 · 研究价值、开源 Benchmark、实验评估与开发路线',
    owns=['研究问题与不夸大创新边界','公开 Benchmark 与自建 KYNXA-Eval','任务成功、工具调用、安全、恢复、资源效率指标','ablation/seed/置信区间/可复现规范','开发路线与 release gate'],
    notowns=['为了论文增加核心模块','只报告 cherry-picked case','把第三方能力宣称为自研创新'],
    objects=['BenchmarkSuite','EvalCase','RunConfig','EvalResult','Ablation','RegressionBaseline','ReproManifest'],
    services=['KYNXA-Eval Harness','Benchmark Adapters','Result Store','Regression Dashboard'],
    flows=['固定版本/模型/seed/environment→执行 benchmark→记录 trace/metric','对 OS/Agent/Tool/RAG/Security 分层评估','每次 runtime/upstream 升级与 baseline 做回归','失败 case 自动分类为 model/tool/authority/context/recovery','研究实验与产品 telemetry 严格区分'],
    invariants=['必须区分事实、外部 benchmark 结果和工程判断','安全 benchmark 不以降低安全边界换成功率','比较时明确模型、硬件、时间、版本','统计结果报告样本数/波动/失败定义','未复现第三方结果不作为内部已证实结论'],
    failures=['benchmark 环境漂移→标 invalid','模型 API 版本变化→新 baseline','隐藏测试失败→保存完整 trace','资源不足→按预定义降级，不能临时改 metric','第三方 benchmark license/数据不可用→替代或跳过'],
    metrics=['task_success_rate','tool_selection_accuracy','prompt_injection_asr','authority_block_rate','resume_success_rate','tokens_per_success','wall_clock_per_success','rag_recall_at_k'],
    tests=['WindowsAgentArena/OSWorld 桌面任务','AgentDojo/Promptfoo/garak 安全回归','BFCL/τ-bench 类工具/策略任务','RAGAS/BEIR 类 Knowledge 测试','kill/restart/replay 自建 durability suite'],
    milestones=['先建立 CodeRepair internal suite','再接 tool/security benchmarks','最后接 desktop/long-horizon work benchmarks']
),
'16_网络架构_Web_Search_VPN_代理_远程连接与实时同步_R3.md': dict(
    title='16 · 网络架构、Web Search、VPN/代理、远程连接与实时同步',
    owns=['NetworkProfile、Direct/System/Custom proxy/PAC/WPAD','KYNXA Web Search/Fetch 与 Provider-native search 区分','SSRF/private network 防护、DNS rebinding 复核','Resident/Remote overlay path 与实时同步','网络 secret 与代理 credential'],
    notowns=['模型 Provider 的服务器端网络行为控制','浏览器扩展代理冒充系统代理','把 VPN 视为权限授予'],
    objects=['NetworkProfile','ProxyPlan','SearchRequest','FetchRequest','RemotePath','ConnectionHealth','SyncCursor'],
    services=['NetworkResolver','SearchWorker','FetchWorker','ProxyResolver','kynxa-net sidecar','RealtimeSyncService'],
    flows=['请求绑定 NetworkProfile→解析 proxy/direct plan','连接前解析目标并做 public/private 分类','redirect/DNS 变化后再次分类','本地模型也可通过 KYNXA Search 获取 Web Evidence','远程连接优先 direct，必要时 relay/degraded 并保留身份认证'],
    invariants=['Cloud model API 与本机 Search 网络路径解耦','Skill network=false 时即使 VPN 开启也不能联网','localhost/private subnet 默认禁止 Web Fetch','proxy password 使用 CredentialRef','网络失败不能偷偷改成 policy 禁止的 Direct'],
    failures=['PROXY_UNREACHABLE→显式错误','search provider 失败→按 profile fallback，不自动云模型 native search','DNS rebinding→阻断','远程 path 切换→session identity 保持','同步 cursor 冲突→基于 revision/causation 合并'],
    metrics=['search_latency_ms','proxy_fail_total','ssrf_block_total','remote_rtt_ms','relay_ratio','sync_conflict_total'],
    tests=['HTTP_PROXY/HTTPS_PROXY 生效','PAC 不同 URL 选择不同路径','302 到私网被阻断','Local DeepSeek + KYNXA Search 工作','Cloud fallback=DENY 时搜索失败不外传 query'],
    milestones=['先 NetworkProfile+Search/Fetch','再 proxy/PAC','最后 remote overlay/realtime sync']
),
}

# standalone database document (restores the previous dedicated detailed doc, no longer compressed to a tiny appendix)
mods['17_数据库_本地持久化_关系模型与索引详细设计_R3.md'] = dict(
    title='17 · 数据库、本地持久化、关系模型与索引详细设计',
    owns=['kynxa.db 业务真相、authority.db 安全真相、文件系统真实字节、可重建索引的四层数据所有权','SQLite schema、FK、revision、transaction、migration、索引与归档','Work/Conversation/Task/CognitiveState/Knowledge/Artifact/Model/Skill/Remote 的关系映射','引用优先文件策略与 blob/file dedup','Qdrant/FTS/session query 等 derived index 的重建'],
    notowns=['Authority secret 明文','把向量库当业务主库','把 Markdown 导出当数据库'],
    objects=['work','conversation','message','task','task_node','cognitive_state','checkpoint','artifact','file_blob','knowledge_source','document_version','chunk','skill','model_provider','model','session_binding','event_outbox','remote_device'],
    services=['DatabaseMigrator','Repository Layer','TransactionCoordinator','BlobStore','IndexRebuilder','RetentionManager'],
    flows=['业务写入在 SQLite transaction 内提交 truth row + outbox','文件先 hash/canonical metadata，再建立 file_blob 引用','索引 worker 消费 outbox 异步更新 FTS/vector','authority.db 只由 Rust Authority 拥有与迁移','恢复时先 SQLite/files，再重建所有 derived index'],
    invariants=['任何表都显式带稳定 ID 与必要的 scope/revision','跨 Work 查询必须携带 work_id/scope filter','重要写操作不跨数据库做“假原子事务”，而用 outbox/reconciliation','Credential secret 不进入 kynxa.db','Session JSONL/DSH storage 不替代 Task/CognitiveState 业务真相'],
    failures=['SQLite busy→有限重试+短事务','migration fail→备份并进入只读恢复','blob missing→标 broken ref 并尝试从源恢复','index out-of-sync→全量 rebuild','outbox stuck→监控并重放幂等 consumer'],
    metrics=['db_write_latency_ms','sqlite_busy_total','migration_duration_ms','index_lag_seconds','blob_dedup_ratio','orphan_ref_total'],
    tests=['同一附件多 Conversation 引用只存一份 blob','删除向量索引后全量重建','Task/Checkpoint 与 DSH session binding 一致恢复','Child Work scope 查询隔离','迁移前后 row count/hash/foreign key 一致'],
    milestones=['先冻结 schema v1 + migration harness','再接 file/blob/index outbox','最后做 backup/restore/integrity sweeps']
)

# module-specific extended notes, to avoid a generic-only package and preserve important project decisions.
extra = {
'00_Global_Engineering_Contract_全局工程契约_安全不变量与跨模块协议_R3.md': '''
### 全局对象与版本规则
- 推荐 UUIDv7/ULID 作为跨进程可持久化 ID；显示名、路径、模型昵称不能承担身份语义。
- `schema_version` 表示结构兼容性，`revision` 表示同一对象的可变世代；审批、Context、缓存和 side effect 必须绑定相关 revision。
- 事件最少包含 `event_id / correlation_id / causation_id / timestamp / producer / schema_version / scope_ref`。
- 错误分为 Validation、Policy、Capability、Dependency、Transient、UnknownSideEffect、Internal 六类；只有 Transient 且满足幂等条件才允许自动重试。

### IPC Envelope
所有 Desktop↔Host、Host↔Agent Runtime、Host↔Authority、Host↔Worker 的跨进程消息使用共同 Envelope。Envelope 不允许把任意 JSON 字符串直接透传到高权限执行器；Authority 接口只接受固定 schema 的 CapabilityRequest/GrantClaim/SideEffectCommit。
''',
'01_总体系统架构与产品蓝图_R3.md': '''
### 推荐进程拓扑
`kynxa-desktop.exe` 只负责 WinUI 3 展示与用户输入；`kynxa-host.exe` 拥有 Work/Task/Knowledge/Model policy 的业务编排；`kynxa-agent-runtime` 运行 DeepSeek Harness；`kynxa-authority.exe` 是独立 Rust TCB；本地模型由 `kynxa-model-runtime` 或同等受控 runtime 管理；浏览器、屏幕、文档解析、Python ML 任务使用按需 worker。

### 生命周期
PC 开机后仅 Resident/网络组件允许轻量常驻。Desktop/Host 可由用户或远程控制启动；模型与浏览器不得因为 Resident 在线而常驻。退出 GUI 时可选择“停止所有任务”或“后台继续”，该选择必须清楚反映到 Host 生命周期。
''',
'02_产品功能需求与_GUI_交互详细设计_R3.md': '''
### 1440×900 基准布局
以 1440×900 为设计基准，左侧导航栏、顶部栏、主对话区、可选右侧预览区均支持 SplitView/GridSplitter 类交互。所有尺寸使用 logical pixel，并对 125%/150% DPI 做缩放测试。左栏收起后保留图标 rail；最近对话区可滚动，不使用过早渐隐遮住项目。

### 模型管理
“模型配置”统一更名“模型管理”。窗口包含“本地模型 / 官方模型 / 自定义模型”，并保留“全部 / 个人 / 共享”平滑分段切换器。自定义连接支持 OpenAI Compatible、Anthropic Compatible、Custom Adapter、Base URL、API Key(Credential Broker)、Model ID 获取/手动添加、Headers/Secret、Network Profile、连接/首 Token/总超时、Retry、能力检测、Context Length、Endpoint Overrides、TLS/自定义 CA、成本与生成参数等。
''',
'03_Work_Conversation_与模型无关_CognitiveState_R3.md': '''
### CognitiveState 最小建议字段
```text
CognitiveState {
  task_id, graph_revision, policy_revision,
  goal, constraints, current_step,
  completed_steps[], unresolved_questions[],
  decisions[], observations[], evidence[],
  retrieved_knowledge[], retrieved_experience[],
  active_skills[], verifier_state,
  artifacts[], environment_state,
  permission_state, resource_budget,
  session_lineage[], updated_at
}
```
不得把模型隐藏推理、KV Cache 或某个 Provider 的私有线程 ID 作为唯一恢复依据。
''',
'04_知识_记忆_经验与决策记忆系统_R3.md': '''
### 检索优先级
Work 内默认：当前 Conversation 附件 → Work Knowledge → Personal Global → Community → Web（若允许）。普通 Chat 不默认读取任意 Work 私有源。Dense/Sparse 只是召回手段，最终排序还要加入 scope、source quality、freshness、version compatibility 与 conflict signal。

### 文档预览与引用
PDF/DOCX/PPTX/图片/代码进入 Knowledge 后仍保留原始 Artifact/FileRef，回答中的 CitationRef 必须能够回到具体 source/version/page/section/line 范围，而不是只给向量 chunk ID。
''',
'05_Skill_Tool_MCP_与社区能力生态_R3.md': '''
### Skill 包
```text
my-skill/
├── SKILL.md
├── kynxa.skill.yaml        # 可选：capability/model/runtime 声明
├── kynxa.lock              # 固定依赖/commit/hash
├── references/
├── templates/
├── examples/
├── scripts/
└── tests/
```
纯 instruction skill 只需 SKILL.md。脚本永远通过受控 tool adapter 运行，不因文件位于 skill 目录而获得执行权。
''',
'06_DeepSeek_Harness_集成_持久任务编排与_Agent_执行内核_R3.md': '''
### 上游事实基线（2026-09-18）
DeepSeek Harness `packages/core` 当前把 `session / system-prompt / tools / agent / agent-loop` 定义为可替换主干；`agent-loop` 负责创建/恢复 agent、模型流式响应、tool dispatch 与 durable session history。`workspace` 是 host-side 的目录/Session 分组能力，对模型不可见；`storage` 保存非 Session 的 host-side durable application data。KYNXA 因此只在 seam 上做 Adapter，而不复制 loop。

### 两层执行模型
```text
KYNXA Durable TaskGraph
  ├─ deterministic node
  ├─ DSH Agent Session
  │    └─ turn → model → tool → observation → next step
  ├─ verifier node
  └─ authority-controlled side effect node
```
Session 完成不自动等于 TaskNode 成功；KYNXA 可以在 Session 后执行编译、测试、hash、schema 等 deterministic verifier。
''',
'07_模型管理_本地模型运行时与异构消费级硬件自适应_R3.md': '''
### 能力路由
能力槽最少包含 General / Coding / Vision / Reasoning / Fast。Conversation 选择的是 Primary Model；复杂任务允许专门模型生成 Observation 回写 CognitiveState。Smart 可以自动路由；Prefer Selected 尽量保持用户模型但可在允许范围内补能力；Strict 不做隐式替换。
''',
'08_能力模块_浏览器_计算机_文件_代码与_Artifact_R3.md': '''
### CodeRepair 首个 Vertical Slice
Work 绑定 repo → 读取工程 → 受控 build → 解析 error observation → agent 生成 patch → patch apply → tests/verifier → Artifact/diff → checkpoint → kill runtime/host → resume → 验证结果一致。该链路是 R3 的首要端到端验收，不再以“能聊天”作为 Agent Runtime 完成标准。
''',
'09_安全架构_权限系统与_Full_Access_R3.md': '''
### Risk Level
L0 纯读取/无敏感影响；L1 可逆本地变更；L2 较大范围文件/进程/网络动作；L3 账号、发布、外部发送、高影响系统操作；L4 金融、身份、高价值不可逆动作。Full Access 可减少 L1-L3 的确认，但不能把 L4/Secret/Audit/Kill Switch 关闭。
''',
'10_Resident_Android_远程控制_设备配对与统一审批中心_R3.md': '''
### 多设备角色
`CONTROLLER / VIEWER / MIXED` 是 Session role，不是永久设备特权。Phone 可作为 Controller，Tablet 可同时作为 Viewer。Direct Input 单独授权；Screen View 与 Agent Command 分离。任何远程 Approval 仍绑定 Authority 的 canonical action digest。
''',
'14_缓存_存储_快照_回放_可观测性与灾难恢复_R3.md': '''
### 真相层次
1. KYNXA 业务真相：`kynxa.db`；2. 安全真相：`authority.db`；3. 文件真实字节：workspace/artifact/blob store；4. DSH Session execution history：session persistence；5. 可重建索引/缓存：FTS/vector/session-query/cache。恢复顺序严格按不可重建程度从前到后。
''',
'15_研究价值_开源_Benchmark_实验评估与开发路线_R3.md': '''
### KYNXA-Eval 推荐覆盖
- WindowsAgentArena / OSWorld：真实桌面与多应用任务。
- AgentDojo / Promptfoo / garak：prompt injection、工具安全和红队回归。
- BFCL / τ 系列：function/tool calling、多轮策略与业务规则。
- BEIR/RAGAS 类：检索与 RAG。
- 自建 Durability Suite：kill/restart、session generation、side-effect UNKNOWN/reconciliation、Work scope 隔离。
每类结果单独报告，禁止合成一个“总分”掩盖安全或可靠性退化。
''',
'16_网络架构_Web_Search_VPN_代理_远程连接与实时同步_R3.md': '''
### 网络与模型解耦
“Local DeepSeek + KYNXA Search”是正式支持场景：本地模型不需要 Provider-native Search。反之，某云 Provider 的 server-side search 不受本机 VPN/代理路径直接控制，UI/Trace 必须明确标记该事实，避免误导。
''',
'17_数据库_本地持久化_关系模型与索引详细设计_R3.md': '''
### 核心表关系建议
`work(parent_work_id)` 形成单父树；`conversation.work_id` 可空；`task.work_id` 必填，`task.conversation_id` 可空；`task_node.task_id` N:1；`cognitive_state.task_id` 维护当前 revision 并可有历史快照；`checkpoint` 保存恢复锚点；`session_binding` 把 task_node 与 DSH session/generation 关联；`artifact` 与 `file_blob` 分离，支持内容去重与多引用。

### 数据库所有权
Desktop 不直接访问数据库；Host 通过 Repository 层访问 `kynxa.db`；Authority 独占 `authority.db`；Agent Runtime 只通过 Host contract 获取必要状态。向量/FTS/DSH query index 均可删除重建，不能成为唯一来源。
'''
}

# Generic full technical expansion builder.
def bullet(items):
    return '\n'.join(f'- {x}' for x in items)

def table(rows, headers=('项目','详细规则')):
    out = [f'| {headers[0]} | {headers[1]} |', '|---|---|']
    for a,b in rows:
        out.append(f'| {a} | {b} |')
    return '\n'.join(out)

def make_expansion(spec):
    ownrows=[(f'OWN-{i+1:02d}',x) for i,x in enumerate(spec['owns'])]
    objrows=[(x,'稳定 ID；显式 scope/revision；序列化需带 schema_version') for x in spec['objects']]
    svcrows=[(x,'只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界') for x in spec['services']]
    failrows=[(f'F-{i+1:02d}',x) for i,x in enumerate(spec['failures'])]
    testrows=[(f'T-{i+1:03d}',x) for i,x in enumerate(spec['tests'])]
    metricrows=[(m,'进入 Flight Recorder/metrics；默认不得包含 raw secret') for m in spec['metrics']]
    mile = '\n'.join(f'{i+1}. {x}' for i,x in enumerate(spec['milestones']))
    return f'''\n\n# Full Technical Expansion · 可编码详细规格\n\n> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。\n\n## A. 模块责任、边界与非目标\n\n### A.1 本模块拥有的责任\n{table(ownrows, ('责任 ID','工程责任'))}\n\n### A.2 明确不拥有\n{bullet(spec['notowns'])}\n\n边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。\n\n## B. 核心对象与数据契约\n{table(objrows, ('对象','契约要求'))}\n\n所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。\n\n## C. 服务划分与依赖方向\n{table(svcrows, ('服务/组件','约束'))}\n\n依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。\n\n## D. 主流程与状态推进\n{chr(10).join(f'{i+1}. {x}' for i,x in enumerate(spec['flows']))}\n\n每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。\n\n## E. 不变量与安全要求\n{bullet(spec['invariants'])}\n\n任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。\n\n## F. 并发、幂等与 Revision\n- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。\n- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。\n- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。\n- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。\n- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。\n\n## G. 错误、恢复与降级\n{table(failrows, ('Failure ID','处理'))}\n\n降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。\n\n## H. 可观测性与性能指标\n{table(metricrows, ('Metric','规则'))}\n\nTrace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。\n\n## I. 验收与回归测试\n{table(testrows, ('Test ID','场景/期望'))}\n\n测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。\n\n## J. 实施顺序\n{mile}\n\n每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。\n'''

# Copy and expand core R3 docs from compact package.
created=[]
for fname, spec in mods.items():
    src = src_md/fname
    if src.exists():
        base = src.read_text('utf-8').strip()
    else:
        base = f"# {spec['title']}\n\n**版本：v1.4.2-R3 · Full Technical Edition**\n\n## 文档目的\n本文件恢复为独立的可编码详细设计，不再作为短附录存在。"
    content = base + '\n' + extra.get(fname,'') + make_expansion(spec)
    dest=OUT/'02_专项详细设计_MD'/fname
    dest.write_text(content, 'utf-8')
    created.append(dest)

# Appendices - expanded.
appendices = {
'Appendix_A_R2_R3_完整迁移矩阵.md': '''# Appendix A · R2 → R3 完整迁移矩阵\n\n本附录用于在不丢失 v1.4/v1.4.1/v1.4.2-R2 详细设计的前提下迁移到 DeepSeek Harness 内核。R3 的基本策略是“**保留产品与安全真相，替换重复的 Agent Runtime 基础设施**”。\n\n| R2 组件/概念 | R3 归属 | 动作 | 说明 |\n|---|---|---|---|\n| Python central Orchestrator | KYNXA Host + DSH Runtime | 重构 | Python 降为 specialized workers |\n| Planner/Agent loop | DeepSeek Harness agent-loop | 替换 | 不再自研通用 ReAct loop |\n| Tool registry | DSH tools + KYNXA Tool Bridge | 复用+适配 | dangerous tool 仍走 Authority |\n| Skill loader | DSH skill + KYNXA Governance | 复用+保留治理 | SKILL.md/版本/信任继续属于 KYNXA |\n| MCP client runtime | DSH/MCP seam | 复用 | 权限和 secret 不下放 |\n| Subagent engine | DSH subagent | 复用 | 子 agent 同样受预算/Authority 约束 |\n| Workflow engine | DSH workflow | 复用 | 复杂编排按需开启 |\n| Work | KYNXA | 保留 | DSH Workspace 不能替代 |\n| TaskGraph | KYNXA | 保留 | 作为 durable outer orchestration |\n| CognitiveState | KYNXA | 保留 | 与模型/Session 解耦 |\n| Context Compiler | KYNXA→DSH adapter | 保留并改接口 | 注入 system-prompt/context seam |\n| Model Manager/Runtime | KYNXA | 保留 | 通过 DSH LLM seam 提供模型 |\n| Knowledge/Memory | KYNXA | 保留 | 只把 evidence/context 交给 DSH |\n| Authority | Rust KYNXA | 完整保留 | 绝不被 DSH approval/sandbox 替代 |\n| kynxa.db | KYNXA | 保留 | 业务 Source of Truth |\n| DSH Session JSONL | DSH Runtime | 新增/明确 | Agent execution history，不是业务 DB |\n| DSH storage/workspace | DSH host-side | 可选 | 仅 runtime 辅助/项目分组 |\n| Android/Resident/Network | KYNXA | 保留 | 与 Harness 正交 |\n\n## 迁移顺序\n1. 冻结 00 Contract 与 Authority API。\n2. 建 `kynxa-agent-runtime`，先跑 dsh minimal/base composition。\n3. 实现 Context/Model/Tool/Event adapters。\n4. 选 CodeRepair Vertical Slice 双跑旧 runtime 与 DSH runtime。\n5. 对比 Task success、tool trace、checkpoint/resume、副作用一次性语义。\n6. 关闭旧通用 agent loop，只保留必要 specialized worker。\n7. 清理旧 Python Orchestrator 隐式权限与重复 session/storage。\n''',
'Appendix_B_DeepSeek_Harness_Upstream_映射与同步策略.md': '''# Appendix B · DeepSeek Harness Upstream 映射与同步策略\n\n基线日期：2026-09-18。DeepSeek Harness 官方仓库当前把 `packages/core` 作为 agent 主干：`scope / session / system-prompt / tools / agent / agent-default-model / agent-loop`。`agent-loop` 负责创建/恢复 agent、模型请求、流式响应、tool dispatch 和 durable session history。`storage` 提供 host-side 非 Session 数据，`workspace` 提供目录/Session 分组且对模型不可见。\n\n## KYNXA 映射\n| Upstream seam | KYNXA 使用方式 | 禁止事项 |\n|---|---|---|\n| session | 记录 agent execution history | 不替代 Task/CognitiveState |\n| system-prompt | 注入 ContextBundle section | 不把 secret 放入 prompt |\n| tools | 展示/分发 KYNXA Tool schema | 不直接执行危险 OS 动作 |\n| agent/agent-loop | 通用 turn/step lifecycle | 不 fork 成 KYNXA 私有大分支 |\n| LLM seam | 接 Model Resolver/Provider | 不让 DSH 保存 master key |\n| skill | Skill runtime | 治理/权限仍在 KYNXA |\n| subagent | child agent backend | child 不得越权 |\n| workflow | complex orchestration | 仅 Deep Work/预算允许时启用 |\n| web | search/fetch primitive | 网络策略/SSRF 仍由 KYNXA |\n| storage | runtime sidecar state | 不存安全真相 |\n| workspace | UI/host 项目分组可选 | 不替代 Work |\n\n## Upstream 策略\n- 锁定 commit/semver；生产构建保留 exact lockfile。\n- KYNXA 默认只新增 package/profile/plugin/adapter；修改 upstream core 必须有独立 patch 文件、原因、覆盖测试与移除计划。\n- 升级流水线自动运行 session format、resume、parallel tools、skill、subagent、workflow、web、Authority Bridge、Model Adapter、kill/restart 回归。\n- upstream breaking change 先在 compatibility branch 验证，不直接落主线。\n''',
'Appendix_C_IPC_Schema_数据对象与事件契约.md': '''# Appendix C · IPC Schema、数据对象与事件契约\n\n## 通用 Envelope\n```json\n{\n  "schema_version": "1",\n  "message_id": "uuidv7",\n  "correlation_id": "uuidv7",\n  "causation_id": "uuidv7|null",\n  "producer": "kynxa-host",\n  "scope": {"work_id": "...", "task_id": "..."},\n  "revision": 42,\n  "type": "CreateSession",\n  "payload": {}\n}\n```\n\n## Host ↔ Agent Runtime\n- CreateSession / ResumeSession / DeliverPrompt / InjectContext / CancelTurn / ReleaseSession / GetSessionProjection。\n- SessionEvent / ModelCallEvent / ToolIntent / ToolResultEvent / SubagentEvent / WorkflowEvent / UsageMetric / FatalError。\n\n## Host ↔ Authority\n- EvaluateCapabilityRequest / CreateApprovalIntent / ClaimGrant / ResolveCredentialRef / CommitSideEffect / ReconcileSideEffect。\n- Authority 的 response 必须有 decision、reason_code、grant_ref/approval_ref、expires_at、policy_revision。\n\n## Host ↔ Model Runtime\n- ResolveModelPlan / LoadModel / UnloadModel / GenerateStream / CancelGeneration / GetHardwareProfile。\n\n## 事件原则\n所有用户可见进度最终映射成稳定事件，而不是让 UI 解析日志字符串。事件 payload 有大小限制，大文件通过 Artifact/FileRef 引用。\n''',
'Appendix_D_验收_测试与_Benchmark_矩阵.md': '''# Appendix D · 验收、测试与 Benchmark 矩阵\n\n| 类别 | P0 场景 | 通过条件 |\n|---|---|---|\n| Chat/UI | 本地 Chat 流式 | 不阻塞 UI；中断可恢复/重试 |\n| Work | Child Work / scope | 无循环；不跨 Work 泄漏 |\n| DSH | kill/resume | Session/TaskNode 一致恢复 |\n| Tool | file/code/browser | schema/timeout/verifier 完整 |\n| Authority | request binding | 参数/revision 改变使批准失效 |\n| Side Effect | UNKNOWN | 只 reconcile，不盲重试 |\n| Credential | use-by-reference | 模型/日志拿不到 raw secret |\n| Model | Smart/Prefer/Strict | 路由遵从 policy |\n| Local Runtime | OOM | 受控 fallback 或明确失败 |\n| Knowledge | scope + citation | 可回原始 source/version |\n| Storage | index loss | 可从 truth store 重建 |\n| Remote | multi-device | role/approval once 语义正确 |\n| Network | SSRF/proxy | 私网阻断；不偷改网络路径 |\n| Security | prompt injection | 无越权 side effect |\n| Recovery | Host/Desktop crash | task/checkpoint/artifact 可恢复 |\n\n## Benchmark 结果规范\n每次公开结果必须记录：代码 commit、DSH upstream commit、模型/版本、provider、硬件、OS、数据集版本、seed、超时、budget、成功定义、样本数与失败分类。不得只给最佳单次。\n''',
'Appendix_E_WinUI3_1440x900_布局与组件基准.md': '''# Appendix E · WinUI 3 · 1440×900 布局与组件基准\n\n本附录固化 GUI 讨论中已经确认的工程原则，避免后续实现把视觉稿当成固定像素截图。\n\n## 基准窗口\n- 设计基准：1440×900 logical px。\n- 主窗口支持缩放；所有主要区域用 Grid + Splitter/Resizable Pane，不写死绝对坐标。\n- 左侧导航、顶部栏、对话主区、可选预览区均有 min/max；用户拖动后的比例本地持久化。\n- 顶部栏需为后续预览、模式、模型、任务状态等入口保留扩展位，不把第一版控件写死。\n\n## 左侧导航\n- Logo、收起侧边栏、搜索、Chat/Work/Library/Knowledge/Models/Skills 等主项。\n- 最近对话采用滚动列表；条目图标和行高偏紧凑，不能因条目增加让整个侧栏失衡。\n- 底部设置入口固定可达。\n\n## Chat/Work\n- Chat 输入框视觉与普通 Chat、Work Conversation 统一，避免进入 Work 后重新发明一套消息组件。\n- Work 是由多个 Conversation/Task/Knowledge/Artifact 组成的长期范围，左栏在 Work 内展示该 Work 的对话。\n- 右侧预览仅在需要时打开，关闭后主内容区自动扩展。\n\n## 图标与资源\n- Logo/主要图标优先 SVG；WinUI 使用 PathIcon/SvgImageSource 等适配。\n- 不在 XAML 中复制复杂路径多份；建立 ResourceDictionary。\n- 图标尺寸、stroke、corner radius、spacing 全部 token 化，后续可统一调整。\n'''
}
for fn, body in appendices.items():
    p=OUT/'02_专项详细设计_MD'/fn
    p.write_text(body,'utf-8'); created.append(p)

# Combined detailed markdown.
order = list(mods.keys()) + list(appendices.keys())
combined=[]
combined.append('# KYNXA v1.4.2-R3 · DeepSeek Harness 内核版 · Full Technical Design Set\n\n**完整版 / 可编码版 / 非 compact draft**  \n日期：2026-09-18\n\n本全集恢复此前详细技术设计的粒度，同时把 Agent Runtime 更新为 DeepSeek Harness-based 架构。旧 v1.4/v1.4.1/v1.4.2-R2 中与 R3 不冲突的细节继续有效；冲突时以 00 Global Engineering Contract、R3 各专项冻结结论以及独立 Rust Authority 边界为准。\n\n## 文档目录\n\n' + '\n'.join(f'- {mods[f]["title"]}' for f in mods) + '\n' + '\n'.join(f'- {Path(f).stem.replace("_", " ")}' for f in appendices) + '\n\n---\n')
for fn in order:
    txt=(OUT/'02_专项详细设计_MD'/fn).read_text('utf-8')
    combined.append('\n\n<div style="page-break-before: always;"></div>\n\n'+txt)
combined_text=''.join(combined)
combined_md=OUT/'01_统一详细主文档'/'KYNXA_v1.4.2-R3_完整详细技术设计全集.md'
combined_md.write_text(combined_text,'utf-8')

# README
readme = f'''# KYNXA v1.4.2-R3 · DeepSeek Harness · 详细完整版\n\n这不是 34 页 compact/统一摘要版，而是恢复“**完整版 / 可编码版**”结构后的最新 R3 文档包。包内同时保留：\n\n- 00–17 共 **18 份独立专项详细设计**；\n- Appendix A–E 共 **5 份详细附录**；\n- 一份把全部专项与附录完整合并的统一 Markdown；\n- 一份统一详细 DOCX 与 PDF（由全部专项生成，不是只放概要）；\n- R3 架构图、统计、文件清单、SHA256 与构建脚本；\n- 旧 34 页 compact R3 主文档作为“冻结总览”保留，方便快速阅读，但它不再代表完整文档量。\n\n## R3 核心修订\nAgent Runtime 以 DeepSeek Harness 的 session/system-prompt/tools/agent/agent-loop 等 seam 为基础；KYNXA 自己继续拥有 Work/CognitiveState/TaskGraph/Knowledge/Model Management/Resource Policy/WinUI Product Runtime；所有高风险副作用仍由独立 Rust Authority 决定和执行。\n\n## 规范优先级\n00 Global Engineering Contract > R3 各详细专项冻结结论 > R3 Full Technical Expansion > 旧 R2/v1.4.x 非冲突细节。\n'''
(OUT/'00_说明与总览'/'README_详细完整版.md').write_text(readme,'utf-8')

# Copy compact summary DOCX/PDF as quick overview.
compact_docx=SRC/'01_统一主文档'/'KYNXA_v1.4.2-R3_统一技术设计_DeepSeekHarness内核版.docx'
compact_pdf=SRC/'01_统一主文档'/'KYNXA_v1.4.2-R3_统一技术设计_DeepSeekHarness内核版.pdf'
if compact_docx.exists(): shutil.copy2(compact_docx, OUT/'00_说明与总览'/'KYNXA_R3_冻结总览_34页.docx')
if compact_pdf.exists(): shutil.copy2(compact_pdf, OUT/'00_说明与总览'/'KYNXA_R3_冻结总览_34页.pdf')

# Copy diagrams.
for p in (SRC/'03_架构图').glob('*'):
    if p.is_file(): shutil.copy2(p, OUT/'03_架构图'/p.name)

# create a fourth diagram describing R3 ownership
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="900" viewBox="0 0 1400 900">
<style>.b{fill:#fff;stroke:#111;stroke-width:2}.t{font:28px sans-serif;fill:#111}.s{font:22px sans-serif;fill:#111}.a{stroke:#111;stroke-width:3;marker-end:url(#m)}</style>
<defs><marker id="m" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#111"/></marker></defs>
<text class="t" x="70" y="65">KYNXA R3 Ownership & Execution Boundaries</text>
<rect class="b" x="70" y="110" width="1260" height="120" rx="16"/><text class="t" x="520" y="160">WinUI 3 Desktop</text><text class="s" x="290" y="205">Chat · Work · Knowledge · Models · Skills · Inbox · Settings</text>
<rect class="b" x="70" y="290" width="600" height="220" rx="16"/><text class="t" x="235" y="340">KYNXA Host (.NET)</text><text class="s" x="115" y="385">Work · TaskGraph · CognitiveState · Context Compiler</text><text class="s" x="115" y="425">Knowledge · Model Policy · Artifact · Checkpoint</text><text class="s" x="115" y="465">business truth: kynxa.db</text>
<rect class="b" x="730" y="290" width="600" height="220" rx="16"/><text class="t" x="895" y="340">DeepSeek Harness Runtime</text><text class="s" x="800" y="385">session · system-prompt · tools · agent · agent-loop</text><text class="s" x="800" y="425">skill · subagent · workflow · web · compaction</text><text class="s" x="800" y="465">agent execution history</text>
<rect class="b" x="70" y="590" width="600" height="210" rx="16"/><text class="t" x="225" y="640">Rust Authority</text><text class="s" x="135" y="685">Policy · Approval · Grant · Credential · Audit</text><text class="s" x="135" y="725">SideEffect Ledger · Device/Financial hard boundary</text><text class="s" x="135" y="765">security truth: authority.db</text>
<rect class="b" x="730" y="590" width="600" height="210" rx="16"/><text class="t" x="915" y="640">Restricted Executors</text><text class="s" x="805" y="685">File · Process · Browser · Computer · Payment</text><text class="s" x="805" y="725">Model Runtime · Parser/ML workers · Network</text>
<line class="a" x1="370" y1="230" x2="370" y2="290"/><line class="a" x1="1030" y1="230" x2="1030" y2="290"/><line class="a" x1="670" y1="400" x2="730" y2="400"/><line class="a" x1="1030" y1="510" x2="1030" y2="590"/><line class="a" x1="730" y1="695" x2="670" y2="695"/>
</svg>'''
(OUT/'03_架构图'/'04_r3_ownership_boundaries.svg').write_text(svg,'utf-8')

# Build full DOCX with pandoc using compact docx as style reference.
full_docx=OUT/'01_统一详细主文档'/'KYNXA_v1.4.2-R3_完整详细技术设计全集.docx'
cmd=['pandoc',str(combined_md),'-o',str(full_docx),'--from','markdown+raw_html','--reference-doc',str(compact_docx)]
subprocess.run(cmd,check=True)

# Metadata scrub if available.
privacy='/home/oai/skills/docx/scripts/privacy_scrub.py'
if Path(privacy).exists():
    scrub=OUT/'01_统一详细主文档'/'_scrub.docx'
    r=subprocess.run(['python',privacy,str(full_docx),'--out',str(scrub)],capture_output=True,text=True)
    if scrub.exists(): scrub.replace(full_docx)

# Copy builder.
shutil.copy2(__file__, OUT/'05_构建脚本'/'build_kynxa_r3_detailed_full.py')

# preliminary stats
md_files=sorted((OUT/'02_专项详细设计_MD').glob('*.md'))
chars=sum(len(p.read_text('utf-8')) for p in md_files)
nonspace=sum(len(re.sub(r'\s+','',p.read_text('utf-8'))) for p in md_files)
cn=sum(len(re.findall(r'[\u4e00-\u9fff]',p.read_text('utf-8'))) for p in md_files)
eng=sum(len(re.findall(r'\b[A-Za-z][A-Za-z0-9_./:+-]*\b',p.read_text('utf-8'))) for p in md_files)
pre={'module_docs':len(mods),'appendices':len(appendices),'markdown_docs':len(md_files),'chars':chars,'nonspace_chars':nonspace,'chinese_chars':cn,'english_tokens':eng}
(OUT/'04_统计与校验'/'PRELIM_STATS.json').write_text(json.dumps(pre,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(pre,ensure_ascii=False,indent=2))
print(full_docx)
