# 06 · DeepSeek Harness 集成、持久任务编排与 Agent 执行内核

**DeepSeek Harness Integration, Durable Orchestration & Agent Execution Runtime**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
本章替代旧《Adaptive Harness》作为 R3 核心重写文档。目标不是“把 DSH 嵌进去就结束”，而是明确谁拥有哪一层生命周期：KYNXA Durable Orchestration 管外层长期任务；DSH 管每个 Agent Session 内的 turn/step/tool/subagent/workflow；Rust Authority 管最终副作用。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| DSH-001 | Core spine | 使用 DSH session/system-prompt/tools/agent/agent-loop 作为可替换主干。 |
| DSH-002 | Durable session | 采用 DSH session persistence；JSONL 是 session 事实，不是 KYNXA 业务真相。 |
| DSH-003 | Composition | 建立 kynxa profile/bundle patch，只装需要能力；避免修改 upstream core。 |
| DSH-004 | Adapters | 至少实现 State/Context/Model/Tool/Event/Telemetry 六类 KYNXA↔DSH Adapter。 |
| DSH-005 | Workspace | DSH Workspace 仅作为可选 Session 项目视图，不替代 KYNXA Work。 |
| DSH-006 | Agent loop ownership | KYNXA 不再复制 ReAct loop、tool dispatch、subagent/workflow 基础设施。 |

## 1. 上游能力映射
当前 DSH 包工作区按能力家族组织：core 提供 session、system-prompt、tools、agent、agent-loop；session 提供持久会话/检查点；skill 提供按需技能；subagent 提供进程内与外部 backend 委派；workflow 支持模型编写 orchestration；web 提供搜索/抓取；storage/workspace 提供 host-side 持久应用状态。R3 采用这些 seam，而不是复制代码。

## 2. kynxa-agent-runtime
建议创建独立 Node/TypeScript 进程，基于 DSH base/minimal composition 装配 KYNXA profile。启动参数仅接受 Host 传入的 profile、socket/pipe endpoint、session home 与诊断级别。Runtime 不读取 authority.db，不持有长期 Credential；它可以缓存模型 schema/Skill catalog，但可随时重建。

## 3. Host Adapter 协议
Host→Runtime：CreateSession、ResumeSession、DeliverPrompt、InjectContext、CancelTurn、ReleaseSession、GetSessionProjection。Runtime→Host：SessionEvent、ModelCallEvent、ToolIntent、ToolResultEvent、SubagentEvent、WorkflowEvent、UsageMetric、FatalError。所有消息带 task_id/node_id/session_id/correlation_id/revision。

## 4. Context Adapter
Host 生成 ContextBundle，Runtime 插入 DSH system-prompt/context section。KYNXA 不改 DSH history 推导规则；只注入当前 Work/Task 所需的外部结构化上下文。ContextBundle 可包含摘要和引用，但不把 Secret 注入 Prompt。revision 变化时记录 context_revision，便于回放。

## 5. Model Adapter
DSH LLM seam 对接 KYNXA Model Resolver：请求方提供 capability requirements 与用户策略，KYNXA 返回具体 endpoint/model/params；本地模型通过 KYNXA Runtime 暴露兼容 provider；官方/自定义模型使用受 Network Profile 与 Credential Broker 控制的 adapter。DSH 只拿短期调用句柄或受控 token，不持久保存 master secret。

## 6. Tool Adapter 与 Authority
DSH tool registry 可展示 KYNXA Tool schema。危险 Tool 的 execute 回调不直接执行系统动作，而是向 Host/Authority 请求 Grant。ApprovalRequired 作为结构化 Tool Observation 回到 agent loop，Host UI 触发审批；批准后用同一 canonical_request_hash 继续，禁止模型偷偷换参数复用批准。

## 7. Session 与 TaskNode
每个 Durable TaskNode 至少可有 0/1 个 active session，也允许因故障产生 session lineage。Node 进入 RUNNING_AGENT 后绑定 session；Session 完成并不等于 Node 成功，Host 还可以跑 programmatic verifier。Node checkpoint 保存 binding、critical observations、artifact refs 与 side-effect state。

## 8. Subagent/Workflow 策略
DSH subagent/workflow 只在 Deep Work 或满足阈值时启用，避免普通任务过度 fan-out。Host 下发 max_children、max_parallel、token_budget、wall_clock、allowed_tool_classes。child 的 Tool 调用仍走相同 Authority Bridge。

## 9. Compaction 与长上下文
DSH compaction 负责 Session 历史可用性；KYNXA Context Compiler 负责长期知识与任务状态。compaction 不能删除/改写必须保留的 Authority/side-effect references；对长任务，Host 可新建 session generation 并注入最新 CognitiveState，而不是无限延长一个 Session。

## 10. 故障恢复
Runtime crash：Host 保持 Task RUNNING/RECOVERING，重启 Runtime，打开持久 Session，验证 SessionBinding 后 resume。模型调用中断：从已提交 Session event/Checkpoint 重新请求，不恢复半个 token。Tool 执行 UNKNOWN：先 reconciliation，再决定继续。DSH storage/query 索引损坏：重建，不影响 KYNXA state。

## 11. Upstream 同步策略
KYNXA 维护 upstream commit/semver 锁与 compatibility matrix。默认只写 plugin/profile/adapter，不修改 core。若确需 patch，保存最小补丁集、原因、测试覆盖与 upstream issue；每次升级跑 session-format、tool contract、skill、subagent、workflow、authority bridge、kill/restart 回归。

## 12. 性能策略
Fast Chat 使用精简 profile，工具/skill/subagent 可以延迟加载；Agent Work 才启用完整 Tool catalog；Deep Work 再启用 workflow/subagent。Host 对 token stream 做小窗口聚合，避免 WinUI Dispatcher 被逐 token 淹没。DSH telemetry 映射到 KYNXA Flight Recorder，但不强制记录敏感 prompt payload。

## Definition of Done
- 旧自研 agent loop 代码可删除/停用
- 同一 TaskNode 可 kill/resume DSH Session
- Authority Bridge 覆盖全部危险 Tool
- DSH Workspace 不污染 Work 语义
- 上游升级有自动回归
- Fast Chat 与 Agent Work profile 可独立

### 上游事实基线（2026-09-18）
DeepSeek Harness `packages/core` 当前把 `session / system-prompt / tools / agent / agent-loop` 定义为可替换主干；`agent-loop` 负责创建/恢复 agent、模型流式响应、tool dispatch 与 durable session history。`workspace` 是 host-side 的目录/Session 分组能力，对模型不可见；`storage` 保存非 Session 的 host-side durable application data。KYNXA 因此只在 seam 上做 Adapter，而不复制 loop。

### 两层执行模型
```text
KYNXA Durable TaskGraph
  ├─ deterministic node
  ├─ DSH Agent Session
  │    └─ turn → model → tool → observation → next step
  ├─ verifier node
  └─ authority-controlled side effect node
```
Session 完成不自动等于 TaskNode 成功；KYNXA 可以在 Session 后执行编译、测试、hash、schema 等 deterministic verifier。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | DeepSeek Harness 作为 Agent Execution Engine 的集成边界 |
| OWN-02 | KYNXA Durable TaskGraph 与 DSH Session/Agent Loop 的双层运行模型 |
| OWN-03 | State/Context/Model/Tool/Event/Telemetry Adapter |
| OWN-04 | subagent/workflow/skill/web/compaction 的启用策略 |
| OWN-05 | upstream 跟踪、bundle/profile 与最小 patch 策略 |

### A.2 明确不拥有
- 重新实现 ReAct/agent loop
- 让 DSH Workspace 替代 KYNXA Work
- 让 DSH approval/sandbox 取代 Rust Authority

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| AgentRuntimeProfile | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| DshSessionRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SessionBinding | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ContextBundle | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ModelRouteHandle | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ToolIntent | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ToolObservation | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RuntimeEvent | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SessionLineage | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| kynxa-agent-runtime | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| DshCompositionFactory | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ContextAdapter | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ModelAdapter | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| AuthorityToolBridge | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| EventAdapter | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| TelemetryAdapter | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| SessionLifecycleManager | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. Host 创建 TaskNode→Runtime CreateSession/ResumeSession
2. agent-loop 请求模型→LLM seam 调 KYNXA Model Resolver
3. 模型 tool call→DSH tools→KYNXA Tool Bridge→Authority/Executor
4. 结果写回 DSH append-only session log，同时投影到 Host Event Stream
5. Node 结束后 Host 再执行 programmatic verifier 并更新 CognitiveState/Checkpoint

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- 默认只通过 upstream extension/plugin/profile 扩展，不 fork core
- DSH Session 是 agent 执行事实，不是 KYNXA Work/Task 业务真相
- DSH storage/workspace 为 host-side runtime 辅助状态，不拥有 KYNXA 数据模型
- 任何 child/subagent 的危险 tool 同样经过 Authority
- Runtime 不读取 authority.db、不持有长期 credential

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | Runtime crash→重启并 resume persisted session |
| F-02 | session schema 不兼容→migration gate/新 generation |
| F-03 | tool UNKNOWN→reconcile before retry |
| F-04 | upstream 升级导致 adapter contract 变化→compat matrix 阻断发布 |
| F-05 | compaction 丢关键引用风险→Host 用 pinned context refs 校验 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| agent_turn_latency_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| tool_intent_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| parallel_tool_call_peak | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| session_resume_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| runtime_crash_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| adapter_contract_error_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| tokens_per_task | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | kill runtime 中途恢复 session |
| T-002 | child subagent 不能绕过 Authority |
| T-003 | 用户 Strict Coder 无 vision 时返回 capability unavailable |
| T-004 | Work 与 DSH Workspace 名称/删除语义互不污染 |
| T-005 | upstream core 升级跑 session/tool/subagent/workflow 回归 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 建立 dsh-base/minimal 的 kynxa profile
2. 实现六类 Adapter
3. 迁移旧自研 agent loop 调用点
4. 启用 subagent/workflow
5. 建立 upstream 自动兼容测试

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
