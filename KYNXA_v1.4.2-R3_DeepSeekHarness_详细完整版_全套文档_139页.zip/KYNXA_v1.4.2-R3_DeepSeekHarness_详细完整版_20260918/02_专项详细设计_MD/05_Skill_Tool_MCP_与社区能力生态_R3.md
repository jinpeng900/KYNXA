# 05 · Skill、Tool、MCP 与社区能力生态

**Skills, Tools, MCP & Ecosystem Governance**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
R3 最大变化之一是“执行复用 DSH，治理保留 KYNXA”。DSH 已提供 tool registry、skill discovery/loading、MCP resources、subagent/workflow 等能力，KYNXA 不再实现一套重复执行内核；KYNXA 负责来源、版本、锁定、Scope、Capability 映射、供应链、回归和 UI。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| SK-001 | Skill Runtime | 优先复用 DSH skill/skill-filesystem/tool-skill。 |
| SK-002 | Tool Surface | Tool 由 DSH 暴露给模型，但高风险 Tool 统一包装为 KYNXA Authority Tool Adapter。 |
| SK-003 | MCP | MCP Tool schema 先 normalize，再映射 KYNXA Capability；MCP server 不是可信边界。 |
| SK-004 | Governance | Install ≠ Trusted ≠ Authorized。 |
| SK-005 | Fork policy | 优先 plugin/profile/patch；只有无 extension seam 时才 fork DSH 核心。 |

## 1. 三层模型
Capability 是 Authority 能表达的原子权限；Tool 是 DSH/Host 暴露的结构化动作；Skill 是可复用 instruction/procedure。Skill 安装不能自动获得 Tool 权限，Tool 注册不能自动获得宿主权限。Experience 只是证据。

## 2. Skill 包与 DSH 映射
KYNXA 继续支持 SKILL.md + 可选 kynxa.skill.yaml/resources/scripts/tests/kynxa.lock。安装时把可供模型读取的 instruction material 投影到 DSH skill provider；manifest 中的 capability、source hash、trust、version 由 KYNXA Registry 保存。scripts 不直接由 DSH 任意执行，必须通过 Tool/Authority 路径。

## 3. Tool Adapter
低风险纯计算 Tool 可直接在 sandbox/worker 内执行。filesystem.write、process.host、browser.submit、credential.use、computer.input 等统一注册成包装 Tool：模型调用→validate schema→CapabilityRequest→Authority→受限执行→Observation。Tool result 必须带 execution_id 与 side_effect_ref。

## 4. MCP
远端/本地 MCP 的 discover/call 只解决“服务暴露了什么”；KYNXA 必须重新计算网络域、Credential、资源 Scope 与风险。MCP 的 input_required/confirmation 不等价于 KYNXA Approval。Schema hash 变化使缓存/SkillIR 失效并触发重新验证。

## 5. Subagent / Workflow
多 Agent 与 orchestration 直接复用 DSH subagent/workflow。Host 通过 budget envelope 限制并发、token、工具和时间；child session 的权限不因 parent 强而无限继承，仍受 TaskNode/Work Scope。外部 Codex/Claude/其他 Harness backend 只作为 less-trusted provider。

## 6. 供应链
Community Skill 固定 source commit/hash/license；禁止默认追踪 main。更新新增 Capability 时重新授权。无许可证或含危险安装脚本的包只允许隔离实验，不进入 Verified。所有 Skill promotion 需要 smoke/regression/safety/replay。

## Definition of Done
- DSH Skill 可加载且 KYNXA Registry 可追踪
- 危险脚本无法绕过 Authority
- MCP schema 变化可检测
- subagent 不跨 Scope
- 升级 DSH 后 Skill 回归通过

### Skill 包
```text
my-skill/
├── SKILL.md
├── kynxa.skill.yaml        # 可选：capability/model/runtime 声明
├── kynxa.lock              # 固定依赖/commit/hash
├── references/
├── templates/
├── examples/
├── scripts/
└── tests/
```
纯 instruction skill 只需 SKILL.md。脚本永远通过受控 tool adapter 运行，不因文件位于 skill 目录而获得执行权。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | Tool 原子执行语义与 Skill Procedure/SOP 分离 |
| OWN-02 | SKILL.md-first 包格式、manifest/lock/resources/scripts/tests |
| OWN-03 | MCP 与第三方仓库适配 |
| OWN-04 | Skill registry、版本、信任、回归与来源锁定 |
| OWN-05 | DSH skill/tool/MCP runtime 复用和 KYNXA governance |

### A.2 明确不拥有
- 权限授予
- 模型选择最终决定
- 原生 Tool 的 OS 特权执行

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| ToolDefinition | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SkillPackage | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SkillManifest | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SkillLock | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SkillVersion | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ToolBinding | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| McpServerProfile | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SkillTestResult | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| PublisherTrust | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| SkillCatalog | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| SkillInstaller | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| SkillScanner | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| SkillCompiler/Adapter | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| MCPManager | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ToolSchemaBridge | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| RegressionGate | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. 安装来源固定 commit/hash→静态扫描→sandbox test→Candidate
2. Verified Skill 运行时通过 DSH 按需加载
3. Skill 声明 capability requirement，但 Authority 独立授权
4. MCP Server 暴露工具先转 KYNXA Tool schema 再进入 Tool Bridge
5. 版本升级保留 lock 与 regression result，失败可回滚

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- Install != Trusted != Authorized
- 存在 script 不代表可直接执行；必须走 Tool/Authority
- Skill preference 不能覆盖用户显式 Model/Privacy Policy
- 第三方 MCP 的 tool description 视为不可信 metadata
- Community 包不得写 policy/credential store

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | 依赖不可解析→安装失败但不污染已验证版本 |
| F-02 | MCP server 超时→断路器/熔断 |
| F-03 | Tool schema 变更→compatibility gate |
| F-04 | Skill 回归失败→保持旧 verified 版本 |
| F-05 | 供应链 hash 不一致→立即 quarantine |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| skill_install_success_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| skill_regression_pass_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| mcp_tool_latency_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| tool_schema_mismatch_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| quarantined_package_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 恶意 Skill 请求读取 Credential→Authority 拒绝 |
| T-002 | Skill 升级后旧 lock 可回滚 |
| T-003 | MCP 返回 prompt injection 文本只作为 data |
| T-004 | DSH skill 按需加载不扩大 tool catalog |
| T-005 | 离线安装本地 package 可完成验证 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先实现本地 SKILL.md + Tool registry
2. 再接 MCP
3. 再做 GitHub/GitLab/Gitee source + trust UI

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
