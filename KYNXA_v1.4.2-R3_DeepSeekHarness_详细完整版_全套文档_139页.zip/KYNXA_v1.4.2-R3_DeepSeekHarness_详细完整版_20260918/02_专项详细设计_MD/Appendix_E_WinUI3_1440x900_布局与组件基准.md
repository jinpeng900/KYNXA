# Appendix E · WinUI 3 · 1440×900 布局与组件基准

本附录固化 GUI 讨论中已经确认的工程原则，避免后续实现把视觉稿当成固定像素截图。

## 基准窗口
- 设计基准：1440×900 logical px。
- 主窗口支持缩放；所有主要区域用 Grid + Splitter/Resizable Pane，不写死绝对坐标。
- 左侧导航、顶部栏、对话主区、可选预览区均有 min/max；用户拖动后的比例本地持久化。
- 顶部栏需为后续预览、模式、模型、任务状态等入口保留扩展位，不把第一版控件写死。

## 左侧导航
- Logo、收起侧边栏、搜索、Chat/Work/Library/Knowledge/Models/Skills 等主项。
- 最近对话采用滚动列表；条目图标和行高偏紧凑，不能因条目增加让整个侧栏失衡。
- 底部设置入口固定可达。

## Chat/Work
- Chat 输入框视觉与普通 Chat、Work Conversation 统一，避免进入 Work 后重新发明一套消息组件。
- Work 是由多个 Conversation/Task/Knowledge/Artifact 组成的长期范围，左栏在 Work 内展示该 Work 的对话。
- 右侧预览仅在需要时打开，关闭后主内容区自动扩展。

## 图标与资源
- Logo/主要图标优先 SVG；WinUI 使用 PathIcon/SvgImageSource 等适配。
- 不在 XAML 中复制复杂路径多份；建立 ResourceDictionary。
- 图标尺寸、stroke、corner radius、spacing 全部 token 化，后续可统一调整。
