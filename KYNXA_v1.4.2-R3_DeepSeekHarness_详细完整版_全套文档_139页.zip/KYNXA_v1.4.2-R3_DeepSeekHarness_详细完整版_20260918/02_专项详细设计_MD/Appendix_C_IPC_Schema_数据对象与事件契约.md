# Appendix C · IPC Schema、数据对象与事件契约

## 通用 Envelope
```json
{
  "schema_version": "1",
  "message_id": "uuidv7",
  "correlation_id": "uuidv7",
  "causation_id": "uuidv7|null",
  "producer": "kynxa-host",
  "scope": {"work_id": "...", "task_id": "..."},
  "revision": 42,
  "type": "CreateSession",
  "payload": {}
}
```

## Host ↔ Agent Runtime
- CreateSession / ResumeSession / DeliverPrompt / InjectContext / CancelTurn / ReleaseSession / GetSessionProjection。
- SessionEvent / ModelCallEvent / ToolIntent / ToolResultEvent / SubagentEvent / WorkflowEvent / UsageMetric / FatalError。

## Host ↔ Authority
- EvaluateCapabilityRequest / CreateApprovalIntent / ClaimGrant / ResolveCredentialRef / CommitSideEffect / ReconcileSideEffect。
- Authority 的 response 必须有 decision、reason_code、grant_ref/approval_ref、expires_at、policy_revision。

## Host ↔ Model Runtime
- ResolveModelPlan / LoadModel / UnloadModel / GenerateStream / CancelGeneration / GetHardwareProfile。

## 事件原则
所有用户可见进度最终映射成稳定事件，而不是让 UI 解析日志字符串。事件 payload 有大小限制，大文件通过 Artifact/FileRef 引用。
