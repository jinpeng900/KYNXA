# Appendix A · R2 → R3 完整迁移矩阵

本附录用于在不丢失 v1.4/v1.4.1/v1.4.2-R2 详细设计的前提下迁移到 DeepSeek Harness 内核。R3 的基本策略是“**保留产品与安全真相，替换重复的 Agent Runtime 基础设施**”。

| R2 组件/概念 | R3 归属 | 动作 | 说明 |
|---|---|---|---|
| Python central Orchestrator | KYNXA Host + DSH Runtime | 重构 | Python 降为 specialized workers |
| Planner/Agent loop | DeepSeek Harness agent-loop | 替换 | 不再自研通用 ReAct loop |
| Tool registry | DSH tools + KYNXA Tool Bridge | 复用+适配 | dangerous tool 仍走 Authority |
| Skill loader | DSH skill + KYNXA Governance | 复用+保留治理 | SKILL.md/版本/信任继续属于 KYNXA |
| MCP client runtime | DSH/MCP seam | 复用 | 权限和 secret 不下放 |
| Subagent engine | DSH subagent | 复用 | 子 agent 同样受预算/Authority 约束 |
| Workflow engine | DSH workflow | 复用 | 复杂编排按需开启 |
| Work | KYNXA | 保留 | DSH Workspace 不能替代 |
| TaskGraph | KYNXA | 保留 | 作为 durable outer orchestration |
| CognitiveState | KYNXA | 保留 | 与模型/Session 解耦 |
| Context Compiler | KYNXA→DSH adapter | 保留并改接口 | 注入 system-prompt/context seam |
| Model Manager/Runtime | KYNXA | 保留 | 通过 DSH LLM seam 提供模型 |
| Knowledge/Memory | KYNXA | 保留 | 只把 evidence/context 交给 DSH |
| Authority | Rust KYNXA | 完整保留 | 绝不被 DSH approval/sandbox 替代 |
| kynxa.db | KYNXA | 保留 | 业务 Source of Truth |
| DSH Session JSONL | DSH Runtime | 新增/明确 | Agent execution history，不是业务 DB |
| DSH storage/workspace | DSH host-side | 可选 | 仅 runtime 辅助/项目分组 |
| Android/Resident/Network | KYNXA | 保留 | 与 Harness 正交 |

## 迁移顺序
1. 冻结 00 Contract 与 Authority API。
2. 建 `kynxa-agent-runtime`，先跑 dsh minimal/base composition。
3. 实现 Context/Model/Tool/Event adapters。
4. 选 CodeRepair Vertical Slice 双跑旧 runtime 与 DSH runtime。
5. 对比 Task success、tool trace、checkpoint/resume、副作用一次性语义。
6. 关闭旧通用 agent loop，只保留必要 specialized worker。
7. 清理旧 Python Orchestrator 隐式权限与重复 session/storage。
