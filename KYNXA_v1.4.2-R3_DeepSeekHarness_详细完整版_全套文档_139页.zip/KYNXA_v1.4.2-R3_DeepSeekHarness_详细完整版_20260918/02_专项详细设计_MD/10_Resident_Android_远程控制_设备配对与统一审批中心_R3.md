# 10 · Resident、Android 远程控制、设备配对与统一审批中心

**Resident, Android Remote Control, Pairing & Approval Center**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
R3 的 Remote 语义保持：Android 是控制平面，不是第二套 Agent Runtime。PC Host 是任务状态单一权威；手机负责远程发指令、查看进度、审批、Pause/Stop 和可选屏幕观察。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| REM-001 | 一次扫码配对 | PairingSession 短 TTL、单次消费。 |
| REM-002 | Disconnect ≠ Unpair | 断线不删除设备身份；撤销必须显式。 |
| REM-003 | Transport identity ≠ Authority permission | 进了网络不代表有控制权。 |
| REM-004 | Android userspace transport | 不抢占用户 VpnService。 |
| REM-005 | 多设备 | 手机 Controller、平板 Viewer 可并发且权限不串用。 |

## 1. Resident
Resident 只负责轻量可达、Host lifecycle、pairing/transport；不加载大模型、不持有 Agent 工具权限。收到远程 Command 后唤醒 Host，由 Host 创建/查询 Task。

## 2. Device Registry
每个设备有 device_id/public key/role/status/last_seen/revocation revision。Authority 验证 DeviceAuth 后再处理远程审批；RemoteTransport peer ID 只是网络事实。

## 3. 远程事件流
Command、Task Events、Approval、Screen Stream 分通道/优先级，Stop/Pause 不应被视频流阻塞。重复 RemoteCommand 使用 request_id 去重，返回原 Task 状态而不是创建第二任务。

## 4. 网络切换
手机 Wi-Fi↔5G、PC VPN/校园网变化后自动重连，不要求重复扫码。Direct 优先、Relay fallback；第一版验收以“可用”优先，不以必须 P2P 或高画质为门槛。

## 5. DSH 关系
手机不直接操纵 DSH Session。它只发 KYNXA Command/Task action，Host 决定是否 DeliverPrompt/CancelTurn/ResumeSession。这样 Remote 与内部 Agent Runtime 解耦。

## Definition of Done
- 真实跨网配对与重连
- 重复命令不重复执行
- 手机审批 request_hash 正确绑定
- Agent Runtime 更换不影响设备配对
- Stop 通道低延迟

### 多设备角色
`CONTROLLER / VIEWER / MIXED` 是 Session role，不是永久设备特权。Phone 可作为 Controller，Tablet 可同时作为 Viewer。Direct Input 单独授权；Screen View 与 Agent Command 分离。任何远程 Approval 仍绑定 Authority 的 canonical action digest。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | Windows Resident 最小常驻、Host start/wake/health |
| OWN-02 | Android Control Plane、QR 一次性配对与设备密钥 |
| OWN-03 | RemoteSession role/permission |
| OWN-04 | 远程 Task 指令、状态、审批与可选 Screen stream |
| OWN-05 | 设备撤销与多设备并发 |

### A.2 明确不拥有
- 模型推理常驻
- 任意远程桌面软件替代
- Authority policy

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| Device | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| PairingIntent | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RemoteSession | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RemoteCommand | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RemoteApproval | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ScreenStreamSession | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ResidentHealth | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| kynxa-resident | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| Android Client | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| DeviceRegistry | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| PairingService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| RemoteGateway | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ScreenStreamWorker | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. PC Resident 等待已配对设备→认证→可启动 Host
2. QR pairing 只在短时窗口有效并交换设备公钥
3. Phone Controller 与 Tablet Viewer 可建立独立 session
4. 远程 approval 最终提交到同一 Authority ApprovalIntent
5. Screen worker 按需启动，session 结束退出

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- 网络可达不等于 KYNXA 授权
- Resident 不加载模型、不保存原始 Credential
- Viewer 默认只读，Controller 也不自动获得 direct input
- 设备撤销立即使后续 token/session 无效
- 远程命令必须带 device/session identity

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | Host 未运行→Resident start host |
| F-02 | 网络切换→session 重连但不重复执行 side effect |
| F-03 | 设备时钟漂移→nonce/sequence 而非仅靠时间 |
| F-04 | Screen encoder crash→控制通道仍可用 |
| F-05 | pairing code 重放→拒绝 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| resident_idle_mb | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| remote_connect_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| pairing_success_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| remote_command_latency_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| screen_fps | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| revoked_session_reject_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 手机 5G + 平板热点同时连接 PC |
| T-002 | 撤销设备后旧 session 失效 |
| T-003 | Host crash 后手机可请求重启并恢复 task |
| T-004 | 远程审批与 PC 并发只消费一次 Grant |
| T-005 | Viewer 不能发送控制命令 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先 pairing+task status+approval
2. 再 host lifecycle
3. 最后 screen view/direct input 可选能力

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
