# 12 · Routine、Intent Subscription 与个人自动化

**Routine, Intent Subscription & Personal Automation**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
Routine 是持久触发器，不是把 DSH agent-loop 永久在线。Scheduler 属于 Host；触发后创建 Task，再按需启动 DSH Session。这样可控资源、权限和恢复。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| AUTO-001 | Trigger ownership | 时间/事件/条件触发由 Host Scheduler 管理。 |
| AUTO-002 | Task per run | 每次 run 产生独立 task/run_id。 |
| AUTO-003 | Budget/permission | 自动化有单独预算与授权上限。 |
| AUTO-004 | No hidden persistence | DSH Session 结束不等于 Routine 消失；Routine 真相在 KYNXA。 |

## 1. Trigger
支持 cron/timezone、文件事件、网络状态、Work 事件、条件轮询与用户意图订阅。睡眠/休眠后的 missed run 按策略 catch-up/skip，不盲目集中补跑。

## 2. 执行
Run 创建 TaskNode，必要时绑定 DSH Session。读取类自动化可低交互；写入/发送/支付仍受 Authority policy。可为 Routine 配置“仅建议、需确认、允许某范围自动执行”。

## 3. 去重与失败
同一个 scheduled occurrence 有 deterministic run key；崩溃恢复不重复创建。连续失败触发 backoff/pause/inbox，而不是无限 agent retry。

## Definition of Done
- 时区/休眠测试
- 重复触发去重
- 自动化权限不超过预设范围
- 失败会停而非无限烧 Token


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | Cron/事件/条件/意图订阅统一触发模型 |
| OWN-02 | RoutineRun 状态机、去重、Snooze/Pause/Skip |
| OWN-03 | 上下文感知自动化与预算 |
| OWN-04 | 休眠/时区/DST/错过运行 |
| OWN-05 | 自动化的权限与通知策略 |

### A.2 明确不拥有
- 任意后台无限循环 Agent
- 自动授予新权限
- 绕过用户 quiet hours

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| Routine | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| Trigger | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| IntentSubscription | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RoutineRun | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RunBudget | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| NotificationPolicy | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| DedupKey | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| RoutineScheduler | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| TriggerEngine | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| IntentMatcher | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| RunCoordinator | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| NotificationService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. Trigger 命中→创建唯一 Run→加载 scope/context→执行 deterministic/agent node
2. 高风险动作仍进入 Approval
3. 失败按策略 retry/backoff 或等待用户
4. 休眠后按 catch-up policy 决定补跑/跳过
5. 重复事件通过 dedup key 合并

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- 自动化不能扩大原授权 scope
- 条件 watch 最高频率/资源预算受限
- 长期运行必须有可暂停/停止/审计入口
- Quiet hours 默认抑制非紧急打扰
- Intent Subscription 解释 why triggered

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | 系统休眠→恢复时 reconciliation |
| F-02 | 时区变化→按 schedule semantics 重算 |
| F-03 | 同一事件多次到达→幂等去重 |
| F-04 | 模型不可用→可降级 deterministic path 或延迟 |
| F-05 | 通知通道失败→保留 Inbox item |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| routine_runs_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| dedup_suppressed_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| missed_run_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| run_latency_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| user_snooze_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | DST 切换不重复关键动作 |
| T-002 | PC 睡眠后按策略补跑 |
| T-003 | 重复 webhook 只创建一项 Run |
| T-004 | Routine 无权限时进入 Needs You 而非静默失败 |
| T-005 | 用户 Pause 后不再触发 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先本地 schedule
2. 再事件/条件
3. 最后 Intent Subscription 与多设备控制

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
