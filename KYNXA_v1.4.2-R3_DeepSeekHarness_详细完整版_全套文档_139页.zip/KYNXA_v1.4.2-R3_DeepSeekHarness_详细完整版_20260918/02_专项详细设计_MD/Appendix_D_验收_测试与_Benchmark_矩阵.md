# Appendix D · 验收、测试与 Benchmark 矩阵

| 类别 | P0 场景 | 通过条件 |
|---|---|---|
| Chat/UI | 本地 Chat 流式 | 不阻塞 UI；中断可恢复/重试 |
| Work | Child Work / scope | 无循环；不跨 Work 泄漏 |
| DSH | kill/resume | Session/TaskNode 一致恢复 |
| Tool | file/code/browser | schema/timeout/verifier 完整 |
| Authority | request binding | 参数/revision 改变使批准失效 |
| Side Effect | UNKNOWN | 只 reconcile，不盲重试 |
| Credential | use-by-reference | 模型/日志拿不到 raw secret |
| Model | Smart/Prefer/Strict | 路由遵从 policy |
| Local Runtime | OOM | 受控 fallback 或明确失败 |
| Knowledge | scope + citation | 可回原始 source/version |
| Storage | index loss | 可从 truth store 重建 |
| Remote | multi-device | role/approval once 语义正确 |
| Network | SSRF/proxy | 私网阻断；不偷改网络路径 |
| Security | prompt injection | 无越权 side effect |
| Recovery | Host/Desktop crash | task/checkpoint/artifact 可恢复 |

## Benchmark 结果规范
每次公开结果必须记录：代码 commit、DSH upstream commit、模型/版本、provider、硬件、OS、数据集版本、seed、超时、budget、成功定义、样本数与失败分类。不得只给最佳单次。
