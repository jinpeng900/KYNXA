# 16 · 网络架构、Web Search、VPN/代理、远程连接与实时同步

**Network Architecture, Web Search, VPN/Proxy, Remote & Realtime**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
R3 网络层继续保持四层解耦：Model Provider ≠ Search Provider ≠ Network Route ≠ Authority Policy。DSH 自带 Web 工具只是 Agent surface，不允许直接绕过 KYNXA Network Profile 与 Authority。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| NET-001 | Follow user network | 尊重系统 VPN/TUN/代理。 |
| NET-002 | Unified Proxy Resolver | Windows 各技术栈不各走各路。 |
| NET-003 | DSH Web Adapter | web-search/fetch 通过 KYNXA Network Worker/Policy。 |
| NET-004 | Remote plane separation | 设备互联与普通 Web egress 分离。 |
| NET-005 | No first-party cloud | KYNXA 不依赖自有云才能工作。 |

## 1. 网络四层
Model Provider 回答“谁推理”；Search Provider 回答“谁找网页”；Network Route 回答“数据从哪里出去”；Authority Policy 回答“允许发送什么到哪里”。切本地/云模型不应改变 Search 能力，也不能隐式改变隐私。

## 2. Windows Proxy
统一 SystemProxyResolver 解析 KYNXA Custom Proxy、HTTP(S)_PROXY/ALL_PROXY/NO_PROXY、Windows user proxy/PAC、WinHTTP、Direct，生成 ProxyPlan 给 .NET/Rust/Browser/Node worker 使用。Secret 由 Credential Broker 引用。

## 3. DSH Web
DSH web-search/fetch 注册为 KYNXA-aware provider：query/URL 先检查 network/search policy；抓取 worker 限制协议、重定向、私网地址、下载大小和 MIME；结果标记 untrusted provenance 后才进入 Session。Provider-native Search 也不得绕过 policy。

## 4. Remote Connectivity Plane
RemoteTransport 独立于 Web egress。Android 使用 userspace transport，不占系统 VpnService；Direct 优先，Relay fallback；网络变化自动迁移。Remote transport 只提供加密可达性，控制权仍需 KYNXA device auth + Authority。

## 5. Realtime
Token Stream、Agent Event、Approval、Remote Command、Screen Stream 有独立 QoS/背压。UI token 可以 16-50ms 聚合；高优先 Stop/Approval 不被大 Artifact/视频堵塞。

## Definition of Done
- 系统 VPN 开关不破坏权限语义
- Node/.NET/Rust 代理路径一致
- DSH Web 无私网 SSRF
- Remote 与 Web egress 可独立关闭
- Stop/Approval 通道在负载下可用

### 网络与模型解耦
“Local DeepSeek + KYNXA Search”是正式支持场景：本地模型不需要 Provider-native Search。反之，某云 Provider 的 server-side search 不受本机 VPN/代理路径直接控制，UI/Trace 必须明确标记该事实，避免误导。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | NetworkProfile、Direct/System/Custom proxy/PAC/WPAD |
| OWN-02 | KYNXA Web Search/Fetch 与 Provider-native search 区分 |
| OWN-03 | SSRF/private network 防护、DNS rebinding 复核 |
| OWN-04 | Resident/Remote overlay path 与实时同步 |
| OWN-05 | 网络 secret 与代理 credential |

### A.2 明确不拥有
- 模型 Provider 的服务器端网络行为控制
- 浏览器扩展代理冒充系统代理
- 把 VPN 视为权限授予

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| NetworkProfile | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ProxyPlan | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SearchRequest | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| FetchRequest | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RemotePath | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ConnectionHealth | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SyncCursor | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| NetworkResolver | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| SearchWorker | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| FetchWorker | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ProxyResolver | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| kynxa-net sidecar | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| RealtimeSyncService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. 请求绑定 NetworkProfile→解析 proxy/direct plan
2. 连接前解析目标并做 public/private 分类
3. redirect/DNS 变化后再次分类
4. 本地模型也可通过 KYNXA Search 获取 Web Evidence
5. 远程连接优先 direct，必要时 relay/degraded 并保留身份认证

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- Cloud model API 与本机 Search 网络路径解耦
- Skill network=false 时即使 VPN 开启也不能联网
- localhost/private subnet 默认禁止 Web Fetch
- proxy password 使用 CredentialRef
- 网络失败不能偷偷改成 policy 禁止的 Direct

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | PROXY_UNREACHABLE→显式错误 |
| F-02 | search provider 失败→按 profile fallback，不自动云模型 native search |
| F-03 | DNS rebinding→阻断 |
| F-04 | 远程 path 切换→session identity 保持 |
| F-05 | 同步 cursor 冲突→基于 revision/causation 合并 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| search_latency_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| proxy_fail_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| ssrf_block_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| remote_rtt_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| relay_ratio | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| sync_conflict_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | HTTP_PROXY/HTTPS_PROXY 生效 |
| T-002 | PAC 不同 URL 选择不同路径 |
| T-003 | 302 到私网被阻断 |
| T-004 | Local DeepSeek + KYNXA Search 工作 |
| T-005 | Cloud fallback=DENY 时搜索失败不外传 query |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先 NetworkProfile+Search/Fetch
2. 再 proxy/PAC
3. 最后 remote overlay/realtime sync

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
