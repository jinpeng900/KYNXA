# 02 · 产品功能需求与 GUI 交互详细设计

**Product Requirements, GUI & Interaction Specification**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
R3 不改变已经冻结的视觉方向：WinUI 3、简洁、留白、信息密度适中。重点是让 DSH 内核“不可见地”融入产品：用户看到的是 Chat/Work/任务/审批/模型，而不是内部 agent-loop 概念。GUI 必须能够解释当前工作状态、模型、工具、权限和恢复，而不暴露 chain-of-thought。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| GUI-001 | 基准画布 | 1440×900 作为标准设计基准，布局使用响应式 Grid/SplitView。 |
| GUI-002 | 区域可拖动 | 侧边栏、预览区、工作区分栏支持拖动调整；尺寸写入本地 UI state。 |
| GUI-003 | 顶部栏 | 保留收起侧边栏、搜索、上下文/模型入口，可后续增加 Preview 等现有体系内组件。 |
| GUI-004 | 模型管理 | “模型配置”统一改名“模型管理”，独立小型浮动窗口/子窗口，支持拖动、关闭、最小化、最大化。 |
| GUI-005 | Work | Work 内对话继续出现在左侧栏目；输入框/消息样式与普通 Chat 保持一致。 |

## 1. 初始界面与导航
左侧导航保持窄而清晰：新建 Chat、搜索、最近对话、Work、Library、Knowledge、Models、Skills、Remote/Tasks、Settings。最近对话数量应足够形成自然滚动，不使用过早渐隐来假装内容结束。图标采用统一 SVG 资产并控制在小尺寸，避免导航抢占主体。顶部栏是独立可调整区域，收起侧栏和搜索位置固定语义。

## 2. Chat
消息区支持 streaming、引用、附件、代码块、工具状态、任务状态。对普通用户只显示“正在读取文件/正在运行测试/等待批准”等可理解步骤；Developer Mode 才显示 DSH session_id、tool_call_id、model_call、profile、checkpoint 等调试信息。消息输入区保持统一视觉，不因进入 Work 更换一套交互。

## 3. Work
Work 是长期容器而非文件夹。左侧在 Work Scope 下显示该 Work 的 Conversation 列表；主体仍是标准对话框。Work Overview 展示目标、最近活动、Tasks、Knowledge、Artifacts、待审批项与模型策略。Child Work 以树形层级展示，但内容访问仍按独立 Scope。

## 4. 模型管理窗口
三个主选项：本地模型 / 官方模型 / 自定义模型；保留“全部 / 个人 / 共享”三段式平滑切换。自定义模型至少包含连接名称、协议、Base URL、API Key（Credential Broker 引用）、Model ID、模型列表获取、认证方式、Headers Secret、Network Profile、连接/首 Token/总超时、Retry、能力检测、Context Length、Endpoint Overrides、TLS/自定义 CA、成本与生成参数。

## 5. Preview 与 Artifact
附件/PDF/DOCX/PPTX/图片/代码可在右侧 Preview Pane 打开，Pane 宽度可拖动。引用点击定位到页码、段落、代码符号或网页来源。Artifact 支持版本、diff、导出与“加入 Library/Knowledge”区分操作。

## 6. 审批与失败
Approval Card 必须说明动作、资源、风险、影响范围、是否一次性、可否撤销。拒绝后 Agent 得到结构化 Observation 继续调整，不把拒绝当异常崩溃。失败卡显示“模型失败/工具失败/Authority 拒绝/网络失败/恢复中”不同类别。

## Definition of Done
- 1440×900 无遮挡
- 所有关键区域支持键盘与鼠标操作
- Work 与 Chat 视觉一致但 Scope 清晰
- 模型管理不泄露 Secret
- Developer Mode 与普通模式信息层级分离

### 1440×900 基准布局
以 1440×900 为设计基准，左侧导航栏、顶部栏、主对话区、可选右侧预览区均支持 SplitView/GridSplitter 类交互。所有尺寸使用 logical pixel，并对 125%/150% DPI 做缩放测试。左栏收起后保留图标 rail；最近对话区可滚动，不使用过早渐隐遮住项目。

### 模型管理
“模型配置”统一更名“模型管理”。窗口包含“本地模型 / 官方模型 / 自定义模型”，并保留“全部 / 个人 / 共享”平滑分段切换器。自定义连接支持 OpenAI Compatible、Anthropic Compatible、Custom Adapter、Base URL、API Key(Credential Broker)、Model ID 获取/手动添加、Headers/Secret、Network Profile、连接/首 Token/总超时、Retry、能力检测、Context Length、Endpoint Overrides、TLS/自定义 CA、成本与生成参数等。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | 1440×900 基准 WinUI 3 桌面信息架构 |
| OWN-02 | 侧边栏、顶部栏、主内容区、预览区与可拖动分隔条 |
| OWN-03 | Chat/Work/Models/Skills/Knowledge/Inbox/Settings 页面 |
| OWN-04 | 流式消息、附件、引用、预览、审批卡、任务状态与错误恢复交互 |
| OWN-05 | 模型管理独立可拖动小窗口 |

### A.2 明确不拥有
- 模型推理实现
- Authority 内部策略求值
- 网络隧道实现

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| NavigationItem | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ConversationCard | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| WorkCard | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| MessageBlock | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| AttachmentRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| CitationRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| PreviewPaneState | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ApprovalCard | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ModelManagerWindowState | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SplitterLayout | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| ShellWindow | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| NavigationViewModel | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ChatViewModel | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| WorkViewModel | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| PreviewService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ApprovalCenterViewModel | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ModelManagerWindow | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| LayoutPersistenceService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. 启动默认进入 Chat；侧边栏支持折叠和宽度拖动
2. 消息流式到达时做 chunk coalescing，避免逐 token UI 更新
3. 点击引用/附件在预览区打开，预览区宽度可拖动
4. 进入 Work 后左侧仍保留该 Work 的 Conversation 列表
5. 模型管理从 Settings/顶部入口打开独立子窗口，支持关闭/最小化/最大化/拖动

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- UI 不显示安全能力即等于授权；审批必须来自 Authority Intent
- 普通用户不直接编辑数据库/路径/secret
- 所有可拖动区域保存合法 min/max 尺寸，窗口缩小时先保证主对话可用
- 对话图标、导航图标保持统一小尺寸与 WinUI 视觉层级
- 不以 WebView2 作为主 GUI 实现

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | Preview renderer 不支持→回退到系统打开/文本摘要 |
| F-02 | 流式断线→保留已显示内容并提供 Retry/Resume |
| F-03 | 模型不可用→显示 capability/fallback 原因 |
| F-04 | 审批过期→卡片明确标记 Expired 而不是静默失败 |
| F-05 | 布局配置损坏→回到 1440×900 默认布局 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| first_interactive_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| stream_ui_updates_per_sec | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| preview_open_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| approval_decision_latency_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| layout_restore_fail_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 1440×900、1920×1080、125%/150% DPI 无裁切 |
| T-002 | 侧边栏/预览/顶部区域拖动后重启恢复 |
| T-003 | Work 内多 Conversation 左栏可滚动并保留最近对话渐进感 |
| T-004 | 模型管理窗口独立拖动/最大化且不阻塞主窗口 |
| T-005 | 大量 token 流式时 UI 线程无明显卡顿 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先冻结 Shell/Chat/Work/Preview 基础组件
2. 再接 Approval/Model Manager
3. 最后接 Android Remote 状态与开发者诊断视图

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
