# 03 · Work、Conversation 与模型无关 CognitiveState

**Work, Conversation & Model-Agnostic Cognitive State**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
R3 坚持“长期状态不能依赖某个模型或某个 DSH Session”。DSH Session 是一次/一段 Agent 执行历史；KYNXA Work/Task/CognitiveState 才是跨模型、跨进程、跨设备和跨版本可恢复的业务状态。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| STATE-001 | Work Tree | 每个 Work 最多一个 parent_work_id，禁止循环。 |
| STATE-002 | Conversation | work_id 可空；NULL 表示普通 Chat。 |
| STATE-003 | Task | Task 属于 Work，可选绑定 Conversation。 |
| STATE-004 | SessionBinding | 一个 TaskNode 可绑定当前 DSH session_id，并保留历史 generation/session lineage。 |
| STATE-005 | CognitiveState | 保存继续任务的最小充分状态，不保存模型私有 KV cache 作为真相。 |

## 1. Work Scope
Work 聚合 Conversation、Task、Knowledge、Artifact、Decision、Memory、ModelPolicy 与 PermissionPolicy。磁盘不跟随逻辑树嵌套移动，避免重命名/移动 Work 引发大规模文件搬迁。父 Work 可聚合元数据，但不得自动继承子 Work 私有知识或 Grant。

## 2. CognitiveState Schema
建议字段：goal、constraints、task_graph_ref、current_node、completed_node_refs、unresolved_questions、decision_refs、evidence_refs、observation_refs、artifact_refs、environment_snapshot、model_policy_revision、permission_scope_ref、resource_budget、verifier_state、recovery_cursor、revision。所有大 payload 使用内容寻址引用，避免单行 JSON 无限制增长。

## 3. TaskGraph 与 DSH 的两层关系
外层 Durable TaskGraph 由 Host 管理，负责依赖、生命周期、预算、审批、跨重启恢复。某个 MODEL/AGENT 类型 TaskNode 的内部实现可以是一段 DSH Session agent loop。DSH 可在该 Session 内自主调用工具、subagent 或 workflow，但它不能越过 TaskNode 的 Scope/预算/Capability envelope。

## 4. SessionBinding
SessionBinding 至少包含 binding_id、task_id、node_id、dsh_session_id、profile、cwd/work_mount、context_revision、model_policy_revision、created_at、released_at、resume_strategy。Agent Runtime 重启后先验证 Session header/cwd 与 Work Scope，再恢复；不允许拿另一个目录的 Session 静默继续。

## 5. Reducer 与事件
CognitiveState 的变更由可审计事件驱动，如 NodeStarted、ObservationCommitted、DecisionAccepted、CheckpointCreated、ApprovalResolved、ArtifactProduced、SessionRebound。模型自然语言不能直接写入 final state；必须先转换为结构化事件并由 Host reducer 校验。

## Definition of Done
- 换模型后可继续任务
- Agent Runtime/Host kill-resume 通过
- Child Work scope 不串
- Session 与 Task 映射可追踪
- 状态 revision 并发冲突可检测

### CognitiveState 最小建议字段
```text
CognitiveState {
  task_id, graph_revision, policy_revision,
  goal, constraints, current_step,
  completed_steps[], unresolved_questions[],
  decisions[], observations[], evidence[],
  retrieved_knowledge[], retrieved_experience[],
  active_skills[], verifier_state,
  artifacts[], environment_state,
  permission_state, resource_budget,
  session_lineage[], updated_at
}
```
不得把模型隐藏推理、KV Cache 或某个 Provider 的私有线程 ID 作为唯一恢复依据。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | Work/Child Work 长期 Scope |
| OWN-02 | Conversation、Task、TaskNode 与 CognitiveState 分层 |
| OWN-03 | Checkpoint/Snapshot/Handoff/Context Compiler |
| OWN-04 | TaskGraph revision 与跨模型恢复 |
| OWN-05 | DSH SessionBinding 与 session lineage |

### A.2 明确不拥有
- DSH 内部 turn/step 历史实现
- 长期 Knowledge 本体
- Authority Grant 真相

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| Work | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| Conversation | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| Task | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| TaskNode | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| CognitiveState | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| Checkpoint | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SessionBinding | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ContextBundle | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ArtifactRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| DecisionRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| WorkService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| TaskService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| CognitiveStateReducer | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| CheckpointService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ContextCompiler | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| SessionBindingService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. Conversation 可属于 Work 或为普通 Chat
2. TaskGraph 外层负责 durable node、依赖、审批、预算、恢复
3. RUNNING_AGENT 节点创建/恢复 DSH SessionBinding
4. 模型切换通过 ContextBundle/Handoff，而不是迁移 KV/CoT
5. Checkpoint 固化关键 Observation、Artifact、side-effect 引用与 graph_revision

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- CognitiveState 不保存私有 chain-of-thought 作为业务真相
- Work 删除采用 tombstone/retention，不直接抹除审计
- Child Work 具有独立 scope，不因父级查看而自动扩权
- session_id 不是 task_id；一项 Task 可产生 session lineage
- Context 编译必须显式带 scope/revision 和 provenance

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | session 丢失→从最新 Checkpoint 创建新 generation |
| F-02 | graph revision 冲突→节点停止并重新规划 |
| F-03 | 并发修改 Work→optimistic revision conflict |
| F-04 | Context 超预算→按重要性压缩，Authority/side-effect refs 不得摘要丢失 |
| F-05 | Artifact 缺失→标记 degraded evidence |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| checkpoint_write_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| resume_success_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| context_bundle_tokens | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| graph_revision_conflict_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| session_generation_count | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 模型 A→模型 B 后目标/约束/证据/Verifier 状态不丢 |
| T-002 | Host kill 后从 checkpoint 恢复 |
| T-003 | 移动 Child Work 做循环检测 |
| T-004 | 同 TaskNode 两个并发 worker 不允许重复 side effect |
| T-005 | 长期会话 compaction 后仍能恢复关键决策 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先实现 Work/Conversation/Task schema
2. 再实现 reducer/checkpoint
3. 最后接 DSH session mapping 与跨模型 handoff

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
