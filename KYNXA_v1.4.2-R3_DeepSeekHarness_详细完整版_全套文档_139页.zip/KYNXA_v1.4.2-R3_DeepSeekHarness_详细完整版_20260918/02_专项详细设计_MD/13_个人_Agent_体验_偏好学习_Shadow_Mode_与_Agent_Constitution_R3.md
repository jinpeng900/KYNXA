# 13 · 个人 Agent 体验、偏好学习、Shadow Mode 与 Agent Constitution

**Personal Agent UX, Preferences, Shadow Mode & Constitution**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
长期个性化仍由 KYNXA 保存结构化偏好和可撤销规则，不交给某个模型 Session。DSH 只在 ContextBundle 中接收当前允许使用的偏好摘要。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| PERS-001 | Structured preference | 偏好有 scope/source/confidence/revision。 |
| PERS-002 | Shadow Mode | 先观察/建议，不自动执行副作用。 |
| PERS-003 | Constitution | 用户定义长期行为原则，但不能放宽 Authority 硬边界。 |
| PERS-004 | Forget | 用户可查看/删除长期偏好与记忆。 |

## 1. Preference
区分显式设置、用户反馈推断、Work 专属偏好与临时上下文。低置信推断不能静默变成硬规则。模型输出“我认为你喜欢…”必须先形成 candidate。

## 2. Constitution
Constitution 影响语气、工作偏好、探索度、汇报方式和是否先询问，但不改变网络、文件、Credential、支付等 Authority policy。

## 3. Shadow
Shadow Mode 让系统在不执行的情况下记录“如果允许我会怎么做”，用于评估工具选择与风险。Shadow trace 可以喂给 benchmark/replay，但不能产生真实 side effect。

## Definition of Done
- 删除偏好后不再进入 Context
- Constitution 不影响硬权限
- Shadow 无副作用
- Work 偏好不泄漏到其他 Work


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | 结构化偏好与 Agent Constitution |
| OWN-02 | Teach KYNXA、Why Asking、Shadow Mode |
| OWN-03 | Do-it-and-tell-me/Inbox/每日简报 |
| OWN-04 | 偏好证据、置信度、可撤销与可忘记 |
| OWN-05 | 探索度与个性化边界 |

### A.2 明确不拥有
- 敏感属性推断
- 隐藏式政治/商业操纵
- 把偏好当权限

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| Preference | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| PreferenceEvidence | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ConstitutionRule | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ShadowSuggestion | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| UserFeedback | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| BriefingItem | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| PreferenceService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ConstitutionEvaluator | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ShadowModeService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| FeedbackRouter | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| BriefingComposer | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. 用户显式 Teach 或从重复行为生成低置信候选
2. 候选先在 Shadow Mode 观察，不直接自动执行
3. 用户确认后提升 preference confidence
4. 冲突偏好按 scope/time/source 解析
5. Why Asking 展示触发规则与当前假设

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- Preference != Permission
- 敏感个人属性默认不推断/不固化
- 用户可查看、编辑、忘记偏好来源
- 失败反馈优先修正行为，不强行解释用户
- 个人化不能覆盖 Authority/Privacy 硬边界

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | 偏好冲突→降级为询问或 scope-specific rule |
| F-02 | 低置信候选→保持 shadow |
| F-03 | 用户撤销→后续 context 不再注入 |
| F-04 | 摘要过度个性化→可关闭/回到中性模式 |
| F-05 | 数据删除后 derived cache 同步清理 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| shadow_accept_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| preference_reversal_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| why_asking_open_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| briefing_dismiss_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 用户修改偏好立即影响后续 task |
| T-002 | 忘记偏好后不再出现 |
| T-003 | Shadow suggestion 不产生真实 side effect |
| T-004 | Work 特定偏好不泄漏到其他 Work |
| T-005 | 偏好不能替代审批 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先 explicit preference
2. 再 shadow learning
3. 最后 briefing/constitution 与长期治理

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
