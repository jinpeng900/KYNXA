# 11 · Agent Wallet、购物 Skill 与 Agent Commerce

**Agent Wallet, Shopping & Commerce**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
Commerce 保留既有边界：KYNXA 不托管用户资金，模型不能直接完成不可逆支付。DSH 可以帮助搜索、比较、准备订单，但最终 Financial Boundary 由 Authority 与支付 Provider adapter 约束。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| COM-001 | No custody | KYNXA 不持有资金。 |
| COM-002 | PaymentIntent | 支付前形成明确金额/商家/订单/币种/收货等 intent。 |
| COM-003 | Financial hard boundary | 模型/Skill/Full Access 不能自动跨越。 |
| COM-004 | Reconciliation | 网络超时 UNKNOWN 时查询而非重复扣款。 |

## 1. Shopping Skill
DSH Skill 可负责任务拆分、商品检索与比较，Search/Browser Tool 受 Network/Authority policy。结果卡必须区分广告/来源/价格时间戳/币种。

## 2. Payment Flow
Agent 只能提出 PaymentIntent；用户在受信 UI 确认 canonicalized 金额和商家；Authority 签发一次性 Transaction Grant；受控 adapter 调起官方支付路径。模型不接收银行卡/CVV/支付密码。

## 3. Side Effect
下单/支付属于 non-idempotent。SENT 后超时进入 UNKNOWN，恢复流程先 query/reconcile。Replay 永远用 recorded result/mock，不能真实扣款。

## Definition of Done
- 支付信息不进 Prompt
- 重复网络请求不重复扣款
- Full Access 不绕过 Financial boundary
- 订单/支付状态可 reconciliation


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | 商品比较/购物卡/订单意图 |
| OWN-02 | PaymentIntent 与 Financial Policy |
| OWN-03 | 不托管资金原则 |
| OWN-04 | 支付认证与多设备批准 |
| OWN-05 | Outbox/Reconciliation、Skip Today、预算与商家策略 |

### A.2 明确不拥有
- 银行清算
- 保存银行卡明文
- 让模型直接调用支付凭证

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| ProductCandidate | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ShoppingPlan | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| OrderIntent | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| PaymentIntent | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| MerchantProfile | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| FinancialPolicy | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| PaymentSideEffect | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| ShoppingSkill | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| CommerceAdapter | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| PaymentCoordinator | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| MerchantVerifier | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| FinancialPolicyEngine(Authority-owned parts) | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. 检索商品→生成候选与证据→用户/策略选择
2. 创建 OrderIntent→最终金额/商家/商品 canonicalize
3. PaymentIntent 进入 Authority L4 hard boundary
4. 外部支付结果不确定→reconciliation 查询
5. 拒绝可进入 Skip Today/替代商品/结束

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- 模型永远拿不到可复用支付 secret
- 价格/数量/收货地址变化使批准失效
- 不得把“已发送请求”误报为“已成功支付”
- 自动购买只在明确预算/商家/品类/上限 scope 内
- 默认保留可审计订单与理由

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | 价格变化→重新确认 |
| F-02 | 库存消失→重新计划 |
| F-03 | 支付网关超时→UNKNOWN |
| F-04 | 商家身份无法确认→阻断 |
| F-05 | 多设备重复确认→只一次成功 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| commerce_plan_to_order_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| price_change_reapproval_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| payment_unknown_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| reconciliation_latency_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 批准后金额被篡改→拒绝 |
| T-002 | 支付超时不二次扣款 |
| T-003 | 预算超限→Authority 阻断 |
| T-004 | 模拟商家/沙盒环境端到端测试 |
| T-005 | 购物推荐明确区分事实、偏好和广告/推广来源 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先只做比较/购物清单
2. 再沙盒订单
3. 最后受控真实支付集成

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
