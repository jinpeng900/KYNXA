# 15 · 研究价值、开源 Benchmark、实验评估与开发路线

**Research Value, Open Benchmarks, Evaluation & Roadmap**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
R3 的研究价值从“自研所有 Agent 组件”转向“成熟 Harness + 可验证产品 Runtime 的系统研究”：重点研究 Durable State、Authority、Model/Context/Tool/Skill 联合调度、消费级本地模型资源适配和真实桌面任务安全性。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| EVAL-001 | 桌面能力 | WindowsAgentArena / OSWorld。 |
| EVAL-002 | Agent 工具与策略 | tau-bench/tau3 类、BFCL。 |
| EVAL-003 | 安全 | AgentDojo、Promptfoo、garak。 |
| EVAL-004 | Work | TheAgentCompany 类真实工作任务。 |
| EVAL-005 | RAG | BEIR/Ragas + 自建 Work scope isolation set。 |
| EVAL-006 | R3 核心消融 | DSH upstream vs KYNXA adapters/Authority/State/Context/Resource。 |

## 1. 评估原则
不把单一模型跑分当 KYNXA 分数。必须区分 model capability、Agent harness capability、product runtime、security、RAG、desktop execution。报告任务集合、环境、模型、profile、权限策略、cold/warm cache 与成本。

## 2. KYNXA-Eval Harness
统一 adapter 驱动 WindowsAgentArena/OSWorld/AgentDojo/ToolCalling/RAG 测试，记录 Task Success、Tool Selection Accuracy、Illegal Tool Rate、Authority Block/False Block、Prompt Injection ASR、Steps、Tokens、TTFT、Wall Time、Recovery Success、Loop Rate、RAG Recall/faithfulness。

## 3. DSH 相关消融
A：纯 DSH baseline；B：DSH + KYNXA Context；C：+ Durable Task/CognitiveState；D：+ Authority；E：+ Model/Resource Policy。这样可以证明增益来自哪些 KYNXA 层，而不是把上游能力当原创。

## 4. 开发路线
Phase 0：adapter/protocol；Phase 1：Fast Chat；Phase 2：CodeRepair Vertical Slice；Phase 3：Knowledge/Preview；Phase 4：Remote/Approval；Phase 5：Benchmark；Phase 6：community Skill/MCP。每阶段先打通最小闭环，再扩能力。

## Definition of Done
- 基准配置可复现
- 安全与能力分开报告
- 至少有 kill/restart/side-effect 测试
- 不夸大 DSH upstream 为 KYNXA 原创
- 每次 DSH 升级跑固定 regression set

### KYNXA-Eval 推荐覆盖
- WindowsAgentArena / OSWorld：真实桌面与多应用任务。
- AgentDojo / Promptfoo / garak：prompt injection、工具安全和红队回归。
- BFCL / τ 系列：function/tool calling、多轮策略与业务规则。
- BEIR/RAGAS 类：检索与 RAG。
- 自建 Durability Suite：kill/restart、session generation、side-effect UNKNOWN/reconciliation、Work scope 隔离。
每类结果单独报告，禁止合成一个“总分”掩盖安全或可靠性退化。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | 研究问题与不夸大创新边界 |
| OWN-02 | 公开 Benchmark 与自建 KYNXA-Eval |
| OWN-03 | 任务成功、工具调用、安全、恢复、资源效率指标 |
| OWN-04 | ablation/seed/置信区间/可复现规范 |
| OWN-05 | 开发路线与 release gate |

### A.2 明确不拥有
- 为了论文增加核心模块
- 只报告 cherry-picked case
- 把第三方能力宣称为自研创新

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| BenchmarkSuite | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| EvalCase | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RunConfig | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| EvalResult | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| Ablation | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RegressionBaseline | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ReproManifest | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| KYNXA-Eval Harness | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| Benchmark Adapters | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| Result Store | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| Regression Dashboard | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. 固定版本/模型/seed/environment→执行 benchmark→记录 trace/metric
2. 对 OS/Agent/Tool/RAG/Security 分层评估
3. 每次 runtime/upstream 升级与 baseline 做回归
4. 失败 case 自动分类为 model/tool/authority/context/recovery
5. 研究实验与产品 telemetry 严格区分

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- 必须区分事实、外部 benchmark 结果和工程判断
- 安全 benchmark 不以降低安全边界换成功率
- 比较时明确模型、硬件、时间、版本
- 统计结果报告样本数/波动/失败定义
- 未复现第三方结果不作为内部已证实结论

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | benchmark 环境漂移→标 invalid |
| F-02 | 模型 API 版本变化→新 baseline |
| F-03 | 隐藏测试失败→保存完整 trace |
| F-04 | 资源不足→按预定义降级，不能临时改 metric |
| F-05 | 第三方 benchmark license/数据不可用→替代或跳过 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| task_success_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| tool_selection_accuracy | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| prompt_injection_asr | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| authority_block_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| resume_success_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| tokens_per_success | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| wall_clock_per_success | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| rag_recall_at_k | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | WindowsAgentArena/OSWorld 桌面任务 |
| T-002 | AgentDojo/Promptfoo/garak 安全回归 |
| T-003 | BFCL/τ-bench 类工具/策略任务 |
| T-004 | RAGAS/BEIR 类 Knowledge 测试 |
| T-005 | kill/restart/replay 自建 durability suite |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先建立 CodeRepair internal suite
2. 再接 tool/security benchmarks
3. 最后接 desktop/long-horizon work benchmarks

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
