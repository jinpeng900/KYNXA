# 00 · Global Engineering Contract：全局工程契约、安全不变量与跨模块协议

**Global Engineering Contract, Trust Boundaries & Cross-Module Protocols**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
本文件是 R3 的最高工程契约。R3 不扩张模块范围，而是把 Agent 执行内核从“由 KYNXA 自研完整 Harness”收敛为“DeepSeek Harness（DSH）作为 less-trusted Agent Execution Engine，KYNXA 继续拥有产品状态、长期任务、知识、模型治理、资源治理与独立 Rust Authority”。任何子模块只能收紧本契约，不能通过 Prompt、插件、DSH Tool、MCP、Remote、Full Access 或用户自定义模型绕过。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| R3-CTR-001 | Intelligence proposes; Authority decides | LLM、DSH agent-loop、subagent、workflow、Skill、MCP、Web 内容只产生建议/工具意图，不拥有宿主高权限。 |
| R3-CTR-002 | DeepSeek Harness 是执行内核，不是产品真相源 | DSH Session/Workspace 可持久，但 Work/Task/CognitiveState/Policy/Artifact 的业务真相仍由 KYNXA 管理。 |
| R3-CTR-003 | Authority 独立 Rust 进程 | Release 禁止把受保护执行退化为 Host/Node/Python 内部函数。 |
| R3-CTR-004 | 范围冻结继续有效 | 不新增一级产品模块；R3 是集成重构。 |
| R3-CTR-005 | 模型与权限正交 | 模型强弱、Provider、DSH profile、Full Access 都不能扩大安全权限。 |
| R3-CTR-006 | 副作用可恢复但不假装 exactly-once | non-idempotent 行为采用 request binding、idempotency key、SideEffectRecord 与 reconciliation。 |

## 1. 可信域与进程边界
R3 将系统分成四类信任域：① UI/Product Host：WinUI 3 + C#，负责交互与业务协调；② Intelligence Plane：DSH、模型、RAG、Skill、MCP、网页与 Python specialized worker，全部按 less-trusted 处理；③ Trusted Authority Core：Rust 独立进程，负责 canonicalization、Policy、Grant、Credential、Device 与安全审计；④ Restricted Executors：只持有单次/限时/限资源的执行能力。DSH 自带的 permission/sandbox/approval 机制可以作为“执行前便利层”，但不能取代 KYNXA Authority 的最终决策。

## 2. Source of Truth 规则
业务状态、安全状态、文件字节、可重建索引与 Agent Session 必须明确分域。kynxa.db 保存 Work/Conversation/Task/CognitiveState/Artifact/ModelPolicy；authority.db 保存 Policy/Grant/Approval/CredentialRef/Device/Audit；Blob Store 保存用户文件与 Artifact 字节；Qdrant/FTS/Session Query 等索引均可重建；DSH Session JSONL 保存 agent turn/tool/model 事件事实。任何单一存储损坏都不得让其他域的安全语义被隐式推导。

## 3. 跨模块 Contract IDs
CapabilityRequest、ApprovalIntent、AuthorizationGrant、SideEffectRecord、TaskNodeExecution、ModelExecutionPlan、ContextBundle、SessionBinding、RemoteCommand 都必须携带稳定 ID、revision、scope 与 correlation_id。跨进程 IPC 不依赖“字符串里约定一下”；Schema 版本升级必须显式。

## 4. Fast / Agent / Deep 三条路径
普通问答走 Fast Chat Path：UI→Host→Context Lite→DSH/Model→Stream，不创建不必要 TaskGraph。需要工具时进入 Agent Work Path：Host 建立 Durable TaskNode，交由 DSH Session 执行。长任务进入 Deep Work Path：允许多个 TaskNode、Checkpoint、subagent/workflow、恢复与资源调度，但副作用仍由 Authority 串行约束。

## 5. 禁止事项
禁止 DSH 直接调用宿主 PowerShell/文件写/浏览器提交等高风险动作；禁止 Community Skill 通过自带脚本绕过 Capability Broker；禁止把 DSH Workspace 等同于 KYNXA Work；禁止将 Session JSONL 作为业务数据库；禁止 Python/Node 保存长期 API Key 明文；禁止恢复流程重复消费一次性 Grant。

## Definition of Done
- 所有高风险能力存在 Authority 测试
- 任何 Tool Call 可追踪到 Task/Session/Grant
- Kill/restart 后不会重复不可逆副作用
- Full Access 仍保留 canonicalization/audit/revoke
- R3 文档间术语与数据所有权一致

### 全局对象与版本规则
- 推荐 UUIDv7/ULID 作为跨进程可持久化 ID；显示名、路径、模型昵称不能承担身份语义。
- `schema_version` 表示结构兼容性，`revision` 表示同一对象的可变世代；审批、Context、缓存和 side effect 必须绑定相关 revision。
- 事件最少包含 `event_id / correlation_id / causation_id / timestamp / producer / schema_version / scope_ref`。
- 错误分为 Validation、Policy、Capability、Dependency、Transient、UnknownSideEffect、Internal 六类；只有 Transient 且满足幂等条件才允许自动重试。

### IPC Envelope
所有 Desktop↔Host、Host↔Agent Runtime、Host↔Authority、Host↔Worker 的跨进程消息使用共同 Envelope。Envelope 不允许把任意 JSON 字符串直接透传到高权限执行器；Authority 接口只接受固定 schema 的 CapabilityRequest/GrantClaim/SideEffectCommit。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | 跨模块术语、稳定 ID、revision/schema_version 规则 |
| OWN-02 | Trust Zone 与 less-trusted / trusted 边界 |
| OWN-03 | CapabilityRequest / ApprovalIntent / AuthorizationGrant / SideEffectRecord 的规范语义 |
| OWN-04 | IPC Envelope、correlation/causation、错误分类与幂等要求 |
| OWN-05 | Model Policy 与 Authority Policy 的正交关系 |

### A.2 明确不拥有
- 具体 GUI 布局
- 具体模型算法
- 具体 Skill SOP
- 某个 Provider 的私有实现

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| ContractId | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ScopeRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| RevisionRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| CapabilityRequest | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ApprovalIntent | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| AuthorizationGrant | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SideEffectRecord | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ModelExecutionPlan | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| EventEnvelope | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| CheckpointRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| Contract Registry | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| Schema Compatibility Gate | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| Scope Resolver | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| Revision Validator | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| Event Envelope Validator | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. 任何模块构造跨进程请求前先绑定 scope/revision/schema_version
2. 受保护动作 canonicalize 后形成 request_hash
3. Authority 只消费结构化请求，不消费模型自然语言作为授权事实
4. 副作用进入 PREPARED→SENT→CONFIRMED/UNKNOWN/FAILED ledger
5. 协议升级通过显式 Contract Migration，而不是局部绕过

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- SEC-001：LLM/Planner/Router/Skill/DSH Runtime 不拥有 ambient host privilege
- SEC-002：Approval != Execution，审批结果不能替代 Grant 校验
- SEC-003：Credential 只允许 use-by-reference，不进入模型上下文与普通日志
- SEC-004：Graph/Policy/Scope/参数 revision 变化使旧批准失效
- SEC-005：non-idempotent side effect 在 UNKNOWN 状态禁止盲重试
- SEC-006：Web/Knowledge/Community Skill 均视为不可信数据
- SEC-007：Full Access 只能放宽交互频率，不关闭 Authority/Audit/Kill Switch

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | 协议版本不兼容→拒绝并返回 CONTRACT_VERSION_UNSUPPORTED |
| F-02 | scope 缺失/漂移→SCOPE_MISMATCH |
| F-03 | revision 过期→STALE_REVISION |
| F-04 | 重复副作用 claim→ALREADY_CLAIMED/RECONCILE |
| F-05 | Authority 不可用→Fail Closed |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| contract_validation_failures_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| stale_revision_reject_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| approval_digest_mismatch_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| side_effect_unknown_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| scope_violation_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 修改审批后的 path/amount，旧 Grant 必须失效 |
| T-002 | 模拟 Python/Node Runtime RCE，不能越过 Authority 读取未授权用户目录 |
| T-003 | 同一 max_uses=1 Grant 在手机和 PC 并发 claim，只能成功一次 |
| T-004 | 支付网络超时进入 UNKNOWN 后只能 reconciliation |
| T-005 | Cloud=DENY 时任何 Skill/Router 都不能静默外传 Work 内容 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先冻结 JSON Schema/IDL 与 Contract ID
2. 为 Host/Authority/Agent Runtime 建 shared conformance tests
3. 把旧散落错误码收敛到统一 taxonomy
4. 把 Contract tests 设为 release gate

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
