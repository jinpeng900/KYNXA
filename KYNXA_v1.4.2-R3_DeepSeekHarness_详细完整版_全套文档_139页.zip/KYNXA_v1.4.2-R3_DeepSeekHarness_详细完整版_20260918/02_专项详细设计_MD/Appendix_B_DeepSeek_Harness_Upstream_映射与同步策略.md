# Appendix B · DeepSeek Harness Upstream 映射与同步策略

基线日期：2026-09-18。DeepSeek Harness 官方仓库当前把 `packages/core` 作为 agent 主干：`scope / session / system-prompt / tools / agent / agent-default-model / agent-loop`。`agent-loop` 负责创建/恢复 agent、模型请求、流式响应、tool dispatch 和 durable session history。`storage` 提供 host-side 非 Session 数据，`workspace` 提供目录/Session 分组且对模型不可见。

## KYNXA 映射
| Upstream seam | KYNXA 使用方式 | 禁止事项 |
|---|---|---|
| session | 记录 agent execution history | 不替代 Task/CognitiveState |
| system-prompt | 注入 ContextBundle section | 不把 secret 放入 prompt |
| tools | 展示/分发 KYNXA Tool schema | 不直接执行危险 OS 动作 |
| agent/agent-loop | 通用 turn/step lifecycle | 不 fork 成 KYNXA 私有大分支 |
| LLM seam | 接 Model Resolver/Provider | 不让 DSH 保存 master key |
| skill | Skill runtime | 治理/权限仍在 KYNXA |
| subagent | child agent backend | child 不得越权 |
| workflow | complex orchestration | 仅 Deep Work/预算允许时启用 |
| web | search/fetch primitive | 网络策略/SSRF 仍由 KYNXA |
| storage | runtime sidecar state | 不存安全真相 |
| workspace | UI/host 项目分组可选 | 不替代 Work |

## Upstream 策略
- 锁定 commit/semver；生产构建保留 exact lockfile。
- KYNXA 默认只新增 package/profile/plugin/adapter；修改 upstream core 必须有独立 patch 文件、原因、覆盖测试与移除计划。
- 升级流水线自动运行 session format、resume、parallel tools、skill、subagent、workflow、web、Authority Bridge、Model Adapter、kill/restart 回归。
- upstream breaking change 先在 compatibility branch 验证，不直接落主线。
