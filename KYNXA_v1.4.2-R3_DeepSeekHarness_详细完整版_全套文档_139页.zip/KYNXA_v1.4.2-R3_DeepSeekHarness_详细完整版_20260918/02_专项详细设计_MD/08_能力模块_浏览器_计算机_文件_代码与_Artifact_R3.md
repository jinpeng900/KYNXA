# 08 · 能力模块：浏览器、计算机、文件、代码与 Artifact

**Capability Contracts, Browser, Computer, File, Code & Artifact**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
R3 把能力模块统一看作 DSH Tool Surface + KYNXA Capability/Authority Contract。模型看到结构化工具；真正执行由受限 worker 或 Authority-controlled executor 完成。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| CAP-001 | File | read 可按 Scope 低风险；write/delete 必须 Authority。 |
| CAP-002 | Code | build/test 默认 sandbox；修改宿主 repository 需 grant。 |
| CAP-003 | Browser | 读取与提交分离；submit/upload/download 按风险处理。 |
| CAP-004 | Computer | 截图/观察与 keyboard/mouse input 分离。 |
| CAP-005 | Artifact | 成果物有 provenance/version/hash，可预览与导出。 |

## 1. Tool Descriptor
每个 Tool 声明 input/output schema、capability、risk_class、idempotency、cacheability、resource_profile、network profile、timeout、observation limits。DSH registry 只消费 presentation schema；KYNXA Capability Registry 保存安全元数据。

## 2. File/Code
文件路径先 canonicalize，再判断 Work mounts/ACL。Repo 工具优先 read/search/diff；代码执行在 sandbox 或受限 build worker。Patch 可以先生成到 staging Artifact，获得批准后才应用到宿主 repository。

## 3. Browser/Web
Web search/fetch 与 interactive browser 分开。抓取内容永远是不可信 Prompt Input。browser.submit、登录、上传、购买等动作必须把最终 URL、method、关键 fields、resource scope 绑定到 Approval/Grant。

## 4. Computer Use
screen capture 只产生 Observation；鼠标/键盘 input 是更高风险 Capability。第一版 Remote 手机端不提供直接鼠标键盘控制，减少攻击面。Computer Agent 产生动作 proposal，Authority/Worker 执行并回传截图 hash/DOM state。

## 5. Artifact
Artifact 是模型/工具产生的可交付对象：文档、图片、diff、报告、代码包、数据集。记录 source task、generation、tool/model refs、hash、mime、preview、final flag。Library 是长期留存；Knowledge 是事实检索源，二者不能自动混为一体。

## Definition of Done
- 危险工具均有 CapabilityRequest
- 路径 TOCTOU 有测试
- 浏览器提交不会被网页 prompt 绕过
- Artifact 来源可追踪
- 代码执行默认隔离

### CodeRepair 首个 Vertical Slice
Work 绑定 repo → 读取工程 → 受控 build → 解析 error observation → agent 生成 patch → patch apply → tests/verifier → Artifact/diff → checkpoint → kill runtime/host → resume → 验证结果一致。该链路是 R3 的首要端到端验收，不再以“能聊天”作为 Agent Runtime 完成标准。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | File/Code/Sandbox/Browser/Computer/Web/Document/Vision/Artifact Tool family |
| OWN-02 | 输入/输出 Schema、capability class、risk level、timeout 与 verifier |
| OWN-03 | Preview/Artifact 版本与 provenance |
| OWN-04 | Computer Use 与直接 API/DOM 的优先级 |
| OWN-05 | Restricted Executor 与 sandbox 约束 |

### A.2 明确不拥有
- 最终授权
- Skill 高层流程
- 模型选择

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| ToolRequest | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ToolResult | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| FileRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| Artifact | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| BrowserSession | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ComputerSession | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SandboxRun | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| PatchSet | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| DocumentView | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| VisionObservation | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| FileExecutor | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| CodeExecutor | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| SandboxManager | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| BrowserWorker | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ComputerWorker | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ArtifactService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| DocumentRenderer | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| VisionWorker | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. 只读工具优先并行；写操作串行且经过 canonical path
2. 代码修改先生成 patch/diff，再测试与 verifier
3. Browser 优先结构化 DOM/API，必要时再视觉/Computer Use
4. Artifact 每次重要修改生成版本与来源链
5. 文件上传/下载/外部发送均重新进入 capability check

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- 路径必须 canonicalize 并防 TOCTOU/path escape
- 工具返回内容视为 untrusted observation
- 直接屏幕/键鼠控制默认更高风险
- Artifact 不等于原始文件；必须有 source/provenance
- Replay 模式不得真实重放支付/发送等副作用

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | sandbox 超时→终止进程树并保留日志 |
| F-02 | browser page crash→重建 session |
| F-03 | 文件被外部修改→etag/hash 冲突 |
| F-04 | patch apply conflict→请求重新读取上下文 |
| F-05 | Computer worker 失去焦点→暂停而非盲点击 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| tool_success_rate | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| sandbox_timeout_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| browser_navigation_ms | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| patch_apply_conflict_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| artifact_versions_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 路径穿越/符号链接逃逸被阻止 |
| T-002 | build→error→patch→test vertical slice |
| T-003 | Browser 页面 prompt injection 不能触发越权 tool |
| T-004 | 大文件预览不一次读入 UI |
| T-005 | Computer Use 操作前后截图/状态 verifier 可关联 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先 File/Code/Sandbox/Artifact
2. 再 Browser/Web
3. 最后 Computer/Vision 高风险交互

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
