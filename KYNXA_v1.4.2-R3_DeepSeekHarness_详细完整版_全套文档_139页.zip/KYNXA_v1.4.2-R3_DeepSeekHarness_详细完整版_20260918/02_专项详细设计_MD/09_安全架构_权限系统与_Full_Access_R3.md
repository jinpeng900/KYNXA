# 09 · 安全架构、权限系统与 Full Access

**Security Architecture, Authority & Full Access**  
版本：v1.4.2-R3  
日期：2026-09-18

## 文档目的
DeepSeek Harness 的引入不能弱化 R2 最重要的安全差异化：模型、Agent Runtime、Skill、MCP、Web、Parser 都是潜在攻击面。Trusted Authority Core 保持最小 TCB、独立 Rust 进程和窄 IPC。

## 冻结决策
| ID/主题 | 冻结结论 | 工程含义 |
| --- | --- | --- |
| SEC-001 | Independent Authority | Release 必须独立进程。 |
| SEC-002 | Canonical request binding | Approval 绑定 canonical_request_hash。 |
| SEC-003 | Credential Broker | 模型只能请求 use-by-reference。 |
| SEC-004 | Fail closed | Authority 不可用时高风险动作失败。 |
| SEC-005 | Full Access | 只是 Policy Mode，不关闭 Authority。 |
| SEC-006 | DSH permissions | 只作为 UX/预筛选层，不是安全最终边界。 |

## 1. Threat Model
攻击来源包括恶意网页/文档、prompt injection、Community Skill、MCP Server、被劫持 Provider、模型幻觉、Agent Runtime compromise、远程设备重放、路径替换/符号链接、Credential 泄露、重复 side effect。Authority 假设 Intelligence Plane 会被完全控制，因此只相信自身 canonicalization 与已验证 IPC identity。

## 2. CapabilityRequest
请求方只提供 action claims 与参数；Authority 自己计算 canonical resource、risk、scope、policy revision。ApprovalIntent 显示给用户的是 canonicalized 结果；批准后签发短 TTL/max_uses/nonce Grant。执行时再次比对 request_hash，防止“批准 A 执行 B”。

## 3. DSH Tool 安全
DSH tool-bash/tool-pwsh/tool-fs 若用于 KYNXA Release，必须替换/包装为 Authority-aware adapter；不能让 agent-loop 直接拿宿主 cwd 与环境变量执行。可以保留 sandbox 版本用于低风险隔离任务。

## 4. Credential
Secret 存在 OS Credential/Authority 管理域；Host/DSH/Skill 只保存 CredentialRef。Provider 调用由受控 network adapter 注入短期 Secret，日志、Session、Prompt、Tool result 均不得包含完整 Key。

## 5. Full Access
Full Access 可以减少交互批准，但依旧保留 Scope、canonicalization、audit、kill switch、L4/Financial boundary、credential policy 和 revoke。用户可配置 Work/Device/Capability 限定，不存在“万能绕过开关”。

## 6. Prompt Injection Defense
安全依赖代码层隔离而非单纯 Prompt。网页/文档标记 untrusted provenance；Context Compiler 不把外部内容放在 system 权威区；工具最小化 exposure；AgentDojo/Promptfoo 等测试用于回归攻击成功率。

## Definition of Done
- Agent Runtime compromise 不能写 authority.db
- Approval 参数替换被拒绝
- Credential 不出现在 Session/日志
- Prompt Injection 不能直接产生高风险执行
- Full Access 仍可审计/撤销

### Risk Level
L0 纯读取/无敏感影响；L1 可逆本地变更；L2 较大范围文件/进程/网络动作；L3 账号、发布、外部发送、高影响系统操作；L4 金融、身份、高价值不可逆动作。Full Access 可减少 L1-L3 的确认，但不能把 L4/Secret/Audit/Kill Switch 关闭。


# Full Technical Expansion · 可编码详细规格

> 本节把 R3 冻结概要展开为可直接进入实现、Schema、IPC、测试和发布 Gate 的详细规格。凡与上方冻结结论冲突，以冻结结论和 00 Global Engineering Contract 为准。

## A. 模块责任、边界与非目标

### A.1 本模块拥有的责任
| 责任 ID | 工程责任 |
|---|---|
| OWN-01 | 独立 Rust Trusted Authority Core |
| OWN-02 | Capability Broker、Policy Engine、Approval Validator、Grant Manager、Credential Broker、Audit、Financial hard boundary |
| OWN-03 | L0-L4 风险、Scope/Duration/Budget、Full Access policy mode |
| OWN-04 | OS-level isolation、Named Pipe ACL/identity/nonce/replay protection |
| OWN-05 | side-effect ledger 与 kill switch |

### A.2 明确不拥有
- Planner 意图
- DSH session
- 业务 GUI 状态

边界原则：**谁拥有事实，谁负责持久化与 revision；谁拥有授权，谁负责最终允许/拒绝；谁消费能力，不因此获得该能力的安全所有权。** 跨模块不得通过共享可变内存或“默认大家都知道”的隐式约定耦合。

## B. 核心对象与数据契约
| 对象 | 契约要求 |
|---|---|
| Policy | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| CapabilityRequest | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| CanonicalAction | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| ApprovalIntent | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| AuthorizationGrant | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| CredentialRef | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| AuditEvent | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| SideEffectRecord | 稳定 ID；显式 scope/revision；序列化需带 schema_version |
| DeviceIdentity | 稳定 ID；显式 scope/revision；序列化需带 schema_version |

所有对象写入前做 schema validation；跨进程传输只传 ID/ref + 最小必要字段。大对象、文件、secret、模型权重不塞入 IPC Envelope。对象被更新时增加 `revision`，并把产生该更新的 `correlation_id` 写入事件/trace。

## C. 服务划分与依赖方向
| 服务/组件 | 约束 |
|---|---|
| kynxa-authority.exe | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| PolicyEngine | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| CapabilityBroker | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| ApprovalService | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| GrantManager | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| CredentialBroker | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| AuditLedger | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |
| SideEffectCoordinator | 只通过已冻结接口与其他模块交互；不得越过 Authority/Scope 边界 |

依赖方向必须可画成 DAG。UI/Agent/Worker 不得反向依赖 Authority 内部实现；Authority 也不得调用 Planner 来决定“用户想做什么”。如需跨层回调，使用事件或显式 request/response contract。

## D. 主流程与状态推进
1. Tool Intent→canonicalization→policy evaluate
2. 低风险内建 Grant 或生成 ApprovalIntent
3. 用户批准绑定 request_hash/policy_revision/graph_revision
4. Executor claim Grant→执行→commit SideEffectRecord
5. UNKNOWN 副作用进入 query/reconcile，禁止自动重复执行

每一步都应留下可诊断事件。可恢复流程必须区分“已计划、已授权、已 claim、已执行、已确认、状态未知”，不能用一个 boolean `done` 代替。若流程中含模型调用，模型输出只能生成候选意图/Observation，最终业务状态仍由 Host/Authority/Verifier 更新。

## E. 不变量与安全要求
- Authority 默认无普通 Internet egress
- Secret 不进入模型/普通 DB/日志
- Full Access 不关闭 L4/credential/audit/kill switch
- 所有远程审批与本机审批共享同一一次性决议语义
- Host/Node/Python 进程即便 RCE 也不应直接获得高权限资源

任何实现优化（缓存、并行、预取、自动批准、批量执行）都不得破坏这些不变量。若优化导致无法证明不变量，应默认关闭该优化，而不是在文档里用“通常安全”替代可验证条件。

## F. 并发、幂等与 Revision
- 写操作使用 optimistic revision 或单写者队列，拒绝 silent last-write-wins。
- 只读节点可并行；会改变外部世界或同一对象的写节点默认串行。
- 自动重试仅用于可证明幂等或尚未发送的步骤；外部副作用进入 UNKNOWN 后先 reconciliation。
- 用户审批、ContextBundle、ModelExecutionPlan、TaskGraph 均绑定 revision；任一关键 revision 变化，旧派生物进入 stale。
- 多设备/多进程同时操作同一对象时，使用稳定 ID + claim/lease/transaction，而不是依赖 UI 是否“看起来只有一个按钮”。

## G. 错误、恢复与降级
| Failure ID | 处理 |
|---|---|
| F-01 | Authority unavailable→fail closed |
| F-02 | Grant expired/claimed→拒绝 |
| F-03 | canonicalization 无法确定→拒绝 |
| F-04 | credential backend locked→需要用户解锁 |
| F-05 | audit 写失败→高风险动作不继续 |

降级必须被记录到用户可理解的 trace/status：例如模型降级、网络代理失效、索引重建、只读恢复模式。不得为了“任务继续”静默扩大 Cloud、权限、Work Scope 或副作用范围。

## H. 可观测性与性能指标
| Metric | 规则 |
|---|---|
| approval_required_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| grant_denied_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| grant_claim_conflict_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| credential_access_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| audit_write_fail_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |
| security_violation_total | 进入 Flight Recorder/metrics；默认不得包含 raw secret |

Trace 采用 correlation/causation 串联 Desktop→Host→AgentRuntime→Authority/Worker。性能优化先测 p50/p95/p99，再决定缓存/并行；安全与正确性指标（越权、重复副作用、恢复一致性）高于纯延迟指标。

## I. 验收与回归测试
| Test ID | 场景/期望 |
|---|---|
| T-001 | 恶意网页诱导上传 SSH key→拒绝 |
| T-002 | 批准后修改金额→旧批准失效 |
| T-003 | Full Access 下金融动作仍需硬边界 |
| T-004 | 模拟 Host RCE 不能直接读 Credential |
| T-005 | remote device revoke 后立即失去审批权 |

测试至少包含：正常路径、用户拒绝、依赖超时、进程崩溃、重启恢复、并发、旧 revision、数据损坏/索引丢失、恶意输入。所有 P0 安全/恢复测试进入 CI release gate。

## J. 实施顺序
1. 先实现 Capability/Grant/Audit 最小闭环
2. 再加 Credential/Device/Financial
3. 最后做系统化红队与 AgentDojo/Promptfoo 回归

每个里程碑的 Definition of Done 必须同时包含代码、Schema、Migration、自动测试、日志/metric、失败路径和最小用户 UI；只完成 happy path 不算模块完成。
