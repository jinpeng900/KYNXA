# KYNXA v1.4.2-R3 · DeepSeek Harness · 详细完整版

这不是 34 页 compact/统一摘要版，而是恢复“**完整版 / 可编码版**”结构后的最新 R3 文档包。包内同时保留：

- 00–17 共 **18 份独立专项详细设计**；
- Appendix A–E 共 **5 份详细附录**；
- 一份把全部专项与附录完整合并的统一 Markdown；
- 一份统一详细 DOCX 与 PDF（由全部专项生成，不是只放概要）；
- R3 架构图、统计、文件清单、SHA256 与构建脚本；
- 旧 34 页 compact R3 主文档作为“冻结总览”保留，方便快速阅读，但它不再代表完整文档量。

## R3 核心修订
Agent Runtime 以 DeepSeek Harness 的 session/system-prompt/tools/agent/agent-loop 等 seam 为基础；KYNXA 自己继续拥有 Work/CognitiveState/TaskGraph/Knowledge/Model Management/Resource Policy/WinUI Product Runtime；所有高风险副作用仍由独立 Rust Authority 决定和执行。

## 规范优先级
00 Global Engineering Contract > R3 各详细专项冻结结论 > R3 Full Technical Expansion > 旧 R2/v1.4.x 非冲突细节。
